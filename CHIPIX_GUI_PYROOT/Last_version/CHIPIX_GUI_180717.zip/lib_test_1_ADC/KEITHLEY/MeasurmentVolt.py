import serial
import sys
import time

if(len(sys.argv) == 2) :
	portName = sys.argv[1]
else :
	portName = "/dev/ttyUSB0"


s = serial.Serial()

s.port      = portName                 # target port for connection
s.baudrate  = 9600                     # Baud rate
s.bytesize  = serial.EIGHTBITS         # number of payload bits per byte
s.parity    = serial.PARITY_NONE       # enable/disable parity check
s.stopbits  = serial.STOPBITS_ONE      # number of stop bits
s.timeout   = None                     # timeout in seconds
s.xonoff    = False                    # enable/disable software flow control
s.rtscts    = False                    # enable/disable RTS/CTS hardware flow control
s.dsrdtr    = False                    # enable/disable DSR/DTR hardware flow control 


s.timeout = 1
s.open()

#cmd = '*RST'

#s.write( cmd + '\r\n' )

cmd = ':SOUR:FUNC CURR'

s.write( cmd + '\r\n' )

cmd = ':SOUR:CURR:MODE FIXED'

s.write( cmd + '\r\n' )

cmd = ':SENS:FUNC "VOLT"'

s.write (cmd + '\r\n' )

cmd = ':SOUR:CURR:RANG MIN'

s.write( cmd + '\r\n' )

cmd = ':SOUR:CURR:LEV 0'

s.write( cmd + '\r\n' )

cmd = ':SENS:VOLT:PROT 5'

s.write( cmd + '\r\n' )

cmd = ':SENS:VOLT:RANGE 5'

s.write( cmd + '\r\n' )

cmd = ':FORM:ELEM VOLT'

s.write( cmd + '\r\n' )

cmd = ':OUTP ON'

s.write( cmd + '\r\n' )

#time.sleep(1)

cmd = ':READ?'

s.write( cmd + '\r\n' )

#cmd = ':OUTP OFF'

#s.write( cmd + '\r\n' )

d = s.read(20)
print type(d)
print d
int (d)
print d









