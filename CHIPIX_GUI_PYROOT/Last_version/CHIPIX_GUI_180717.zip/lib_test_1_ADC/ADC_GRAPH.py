import ROOT

def ADCGraphEx(self):

	self.ADC1 = ROOT.TGHorizontalFrame( self.tab4 )

	self.ReadADCButton = ROOT.TGTextButton( self.ADC1 ,"   Read ADC   ")
      	self.Do_ReadADC = ROOT.TPyDispatcher( self.ReadADC ) # this command translate the python command in C++ launguage I think
	self.ReadADCButton.Connect('Clicked()' , 'TPyDispatcher' , self.Do_ReadADC, 'Dispatch()')
	self.ADC1.AddFrame(self.ReadADCButton, ROOT.TGLayoutHints(ROOT.kLHintsTop|ROOT.kLHintsLeft, 10,10,10,10))


	self.ReadADCLabel= ROOT.TGLabel(self.ADC1, "ADC reading")
        self.ADC1.AddFrame(self.ReadADCLabel, ROOT.TGLayoutHints(ROOT.kLHintsTop|ROOT.kLHintsLeft,40,2,12,10))


        self.ReadADCValue = ROOT.TGLabel(self.ADC1, "            " )
	self.ReadADCValue.SetForegroundColor(234)
	#self.ReadADCValue.SetBackgroundColor (ROOT.kWhite)

        self.ADC1.AddFrame(self.ReadADCValue,ROOT.TGLayoutHints(ROOT.kLHintsExpandX|ROOT.kLHintsExpandY,10,2,12,10))

	self.tab4.AddFrame(self.ADC1,ROOT.TGLayoutHints(ROOT.kLHintsTop|ROOT.kLHintsLeft, 10,10,10,10))


	
	self.ADC2 = ROOT.TGHorizontalFrame( self.tab4 )
	
	self.tabsFrameADC = ROOT.TGTab(self.ADC2, 650, 200)
       	self.tabsFrameADC.DrawBorder()

	self.tabA1 = self.tabsFrameADC.AddTab("  Calibration   ") # **NOTE! Each tab is now a ROOT.TGCompositeFrame object

        self.tabB2 = self.tabsFrameADC.AddTab("  Noise   ") # **NOTE! Each tab is now a ROOT.TGCompositeFrame object

        self.tabC3 = self.tabsFrameADC.AddTab("  ?   ") # **NOTE! Each tab is now a ROOT.TGCompositeFrame object

	self.tabD4 = self.tabsFrameADC.AddTab("  ?   ") # **NOTE! Each tab is now a ROOT.TGCompositeFrame object
		
	self.tabE5 = self.tabsFrameADC.AddTab("  ?   ") 

                # ad the Tabs to the Frame

       


	#### CALIBRATION LEVEL tab ####

	self.ADCFrame1 = ROOT.TGHorizontalFrame (self.tabA1)
	self.Canvas_ADC  = ROOT.TRootEmbeddedCanvas( 'ADC Calibration', self.ADCFrame1, 600, 450 )
	self.ADCFrame1.AddFrame(self.Canvas_ADC, ROOT.TGLayoutHints(ROOT.kLHintsTop|ROOT.kLHintsLeft, 10, 5, 0, 5))  

	self.ADCFrame2 = ROOT.TGVerticalFrame( self.ADCFrame1 )

	self.ADCButton = ROOT.TGTextButton( self.ADCFrame2 ,"   Calibrate ADC   ")
	self.Do_ADC = ROOT.TPyDispatcher( self.ADC_Calibration ) # this command translate the python command in C++ launguage I think
	self.ADCButton.Connect('Clicked()' , 'TPyDispatcher' , self.Do_ADC,'Dispatch()')
	self.ADCFrame2.AddFrame(self.ADCButton, ROOT.TGLayoutHints(ROOT.kLHintsTop|ROOT.kLHintsLeft,50,10,0,10))
	
	self.ADCSTOPButton = ROOT.TGTextButton( self.ADCFrame2 ,"   STOP   ")
	self.Do_STOP_Button = ROOT.TPyDispatcher( self.STOP_Button) # this command translate the python command in C++ launguage I think
	self.ADCSTOPButton.Connect('Clicked()' , 'TPyDispatcher' , self.Do_STOP_Button,'Dispatch()')
	self.ADCFrame2.AddFrame(self.ADCSTOPButton, ROOT.TGLayoutHints(ROOT.kLHintsTop|ROOT.kLHintsLeft,50,10,10,10))
	
	self.ADCFITButton = ROOT.TGTextButton( self.ADCFrame2 ,"   FIT   ")
	#self.Do_FIT = ROOT.TPyDispatcher( self.FIT) # this command translate the python command in C++ launguage I think
	#self.ADCFITButton.Connect('Clicked()' , 'TPyDispatcher' , self.Do_FIT,'Dispatch()')
	self.ADCFrame2.AddFrame(self.ADCFITButton, ROOT.TGLayoutHints(ROOT.kLHintsTop|ROOT.kLHintsLeft,50,10,10,10))

	self.ADCFrame1.AddFrame(self.ADCFrame2, ROOT.TGLayoutHints(ROOT.kLHintsTop|ROOT.kLHintsLeft, 10,10,0,10))

	self.tabA1.AddFrame(self.ADCFrame1,ROOT.TGLayoutHints(ROOT.kLHintsTop|ROOT.kLHintsLeft, 10,10,10,10)) 
 
        self.ADC2.AddFrame(self.tabsFrameADC,ROOT.TGLayoutHints(ROOT.kLHintsExpandX|ROOT.kLHintsExpandY,10,10,0,0) )
	self.tab4.AddFrame(self.ADC2,ROOT.TGLayoutHints(ROOT.kLHintsTop|ROOT.kLHintsLeft, 10,10,0,10))          
