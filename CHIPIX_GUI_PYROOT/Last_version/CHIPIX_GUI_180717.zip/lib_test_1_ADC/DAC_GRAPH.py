import ROOT

def DAC_Graph_Ex(self):

	
	self.tabsFrameDAC = ROOT.TGTab(self.tab5, 650, 200)
       	self.tabsFrameDAC.DrawBorder()

	self.tabA = self.tabsFrameDAC.AddTab("  Calibration  ") # **NOTE! Each tab is now a ROOT.TGCompositeFrame object

        self.tabB = self.tabsFrameDAC.AddTab("  DNL   ") # **NOTE! Each tab is now a ROOT.TGCompositeFrame object

        self.tabC = self.tabsFrameDAC.AddTab("  ...   ") # **NOTE! Each tab is now a ROOT.TGCompositeFrame object

	self.tabD = self.tabsFrameDAC.AddTab("  ...   ") # **NOTE! Each tab is now a ROOT.TGCompositeFrame object
		
	self.tabE = self.tabsFrameDAC.AddTab("  ...   ") 

                # ad the Tabs to the Frame

        self.tab5.AddFrame(self.tabsFrameDAC,ROOT.TGLayoutHints(ROOT.kLHintsExpandX|ROOT.kLHintsExpandY,10,20,20,0) )



	#### CALIBRATION LEVEL tab ####

	self.CalLevelFrame1 = ROOT.TGHorizontalFrame (self.tabA )
	self.Canvas_CalLevel  = ROOT.TRootEmbeddedCanvas( 'CAL_DAC_cvs', self.CalLevelFrame1, 600, 500 )
	self.CalLevelFrame1.AddFrame(self.Canvas_CalLevel, ROOT.TGLayoutHints(ROOT.kLHintsTop|ROOT.kLHintsLeft, 10, 5, 0, 5))  

	self.CalLevelFrame2 = ROOT.TGVerticalFrame( self.CalLevelFrame1 )
	
	self.CalLevel_ComboBox = ROOT.TGComboBox(self.CalLevelFrame2, 1)
	self.CalLevel_ComboBox.Resize(110,20)

 	self.CalLevel_ComboBox.AddEntry("  CAL Level  ",1)
	self.CalLevel_ComboBox.AddEntry("  ICtrl DAC  ",2)  
	self.CalLevel_ComboBox.AddEntry("   DNL DAC   ",3)  
	self.CalLevel_ComboBox.AddEntry("   VBL DAC   ",4)  
	self.CalLevel_ComboBox.AddEntry("   IBIASP1   ",5)  
	self.CalLevel_ComboBox.AddEntry("   IBIASP2   ",6)  
	self.CalLevel_ComboBox.AddEntry("  IBIAS DISC ",7)  
	self.CalLevel_ComboBox.AddEntry("   IBIAS SF  ",8) 
	self.CalLevel_ComboBox.AddEntry("  VRef KRUM  ",9) 
	self.CalLevel_ComboBox.AddEntry("  IBIAS FEED ",10) 
	#self.CalLevel_ComboBox.AddEntry("    ILDAC    ",11) 
	#self.CalLevel_ComboBox.AddEntry("    IGDAC    ",12) 
	#self.CalLevel_ComboBox.AddEntry("  	  ",13) 

	self.CalLevelFrame2.AddFrame(self.CalLevel_ComboBox, ROOT.TGLayoutHints(ROOT.kLHintsTop|ROOT.kLHintsLeft,50,10,0,10))


	self.CalLevelButton = ROOT.TGTextButton( self.CalLevelFrame2 ,"   Calibrate   ")
	self.Do_Calibrate_DAC = ROOT.TPyDispatcher( self.Calibrate_DAC ) # this command translate the python command in C++ launguage I think
	self.CalLevelButton.Connect('Clicked()' , 'TPyDispatcher' , self.Do_Calibrate_DAC,'Dispatch()')
	self.CalLevelFrame2.AddFrame(self.CalLevelButton, ROOT.TGLayoutHints(ROOT.kLHintsTop|ROOT.kLHintsLeft,50,10,0,10))

	self.CalLevelSTOPButton = ROOT.TGTextButton( self.CalLevelFrame2 ,"   STOP   ")
	self.Do_STOP_Button = ROOT.TPyDispatcher( self.STOP_Button) # this command translate the python command in C++ launguage I think
	self.CalLevelSTOPButton.Connect('Clicked()' , 'TPyDispatcher' , self.Do_STOP_Button,'Dispatch()')
	self.CalLevelFrame2.AddFrame(self.CalLevelSTOPButton, ROOT.TGLayoutHints(ROOT.kLHintsTop|ROOT.kLHintsLeft,50,10,0,10))
	
	self.CalLevelFITButton = ROOT.TGTextButton( self.CalLevelFrame2 ,"   FIT   ")
	self.Do_FIT = ROOT.TPyDispatcher( self.FIT) # this command translate the python command in C++ launguage I think
	self.CalLevelFITButton.Connect('Clicked()' , 'TPyDispatcher' , self.Do_FIT,'Dispatch()')
	self.CalLevelFrame2.AddFrame(self.CalLevelFITButton, ROOT.TGLayoutHints(ROOT.kLHintsTop|ROOT.kLHintsLeft,50,10,0,10))
	
	self.CalLevel_FitRange_Label = ROOT.TGLabel ( self.CalLevelFrame2, " Linear Fit Range " )
	self.CalLevelFrame2.AddFrame(self.CalLevel_FitRange_Label, ROOT.TGLayoutHints(ROOT.kLHintsTop|ROOT.kLHintsLeft,50,10,10,10))

	self.CalLevelFrame3a = ROOT.TGHorizontalFrame (self.CalLevelFrame2 )
	self.CalLevel_FitRange_Label_Min = ROOT.TGLabel ( self.CalLevelFrame3a, " Min " )
	self.CalLevelFrame3a.AddFrame(self.CalLevel_FitRange_Label_Min, ROOT.TGLayoutHints(ROOT.kLHintsTop|ROOT.kLHintsLeft,10,10,0,0))
	self.CalLevel_FitRange_Min = ROOT.TGNumberEntry(self.CalLevelFrame3a, 1,9,999,ROOT.TGNumberFormat.kNESInteger ,ROOT.TGNumberFormat.kNEANonNegative, ROOT.TGNumberFormat.kNELLimitMinMax, 1 , 1023 );
        self.CalLevelFrame3a.AddFrame(self.CalLevel_FitRange_Min,ROOT.TGLayoutHints(ROOT.kLHintsExpandX|ROOT.kLHintsExpandY,10,10,0,0))
	
	self.CalLevelFrame2.AddFrame(self.CalLevelFrame3a, ROOT.TGLayoutHints(ROOT.kLHintsTop|ROOT.kLHintsLeft, 10,10,0,5))
	
	self.CalLevelFrame3b = ROOT.TGHorizontalFrame (self.CalLevelFrame2 )
	self.CalLevel_FitRange_Label_Max = ROOT.TGLabel ( self.CalLevelFrame3b, " Max" )
	self.CalLevelFrame3b.AddFrame(self.CalLevel_FitRange_Label_Max, ROOT.TGLayoutHints(ROOT.kLHintsTop|ROOT.kLHintsLeft,10,10,0,10))
	self.CalLevel_FitRange_Max = ROOT.TGNumberEntry(self.CalLevelFrame3b, 1023,9,999,ROOT.TGNumberFormat.kNESInteger ,ROOT.TGNumberFormat.kNEANonNegative, ROOT.TGNumberFormat.kNELLimitMinMax, 1 , 1023 );
        self.CalLevelFrame3b.AddFrame(self.CalLevel_FitRange_Max,ROOT.TGLayoutHints(ROOT.kLHintsExpandX|ROOT.kLHintsExpandY,10,10,0,10))

	self.CalLevelFrame2.AddFrame(self.CalLevelFrame3b, ROOT.TGLayoutHints(ROOT.kLHintsTop|ROOT.kLHintsLeft, 10,10,0,0))
	
	
	
	self.CalLevel_Dispersion_Button = ROOT.TGTextButton( self.CalLevelFrame2 ,"  Dispersion of Measurments   ")
	self.Do_Dispersion = ROOT.TPyDispatcher( self.CalLevel_Dispersion) # this command translate the python command in C++ launguage I think
	self.CalLevel_Dispersion_Button.Connect('Clicked()' , 'TPyDispatcher' , self.Do_Dispersion,'Dispatch()')
	self.CalLevelFrame2.AddFrame(self.CalLevel_Dispersion_Button, ROOT.TGLayoutHints(ROOT.kLHintsTop|ROOT.kLHintsLeft,20,10,10,10))

	self.CalLevelFrame4a = ROOT.TGHorizontalFrame (self.CalLevelFrame2 )
	self.CalLevel_Dispersion_Code_Label = ROOT.TGLabel ( self.CalLevelFrame4a, " DAC Code" )
	self.CalLevelFrame4a.AddFrame(self.CalLevel_Dispersion_Code_Label, ROOT.TGLayoutHints(ROOT.kLHintsTop|ROOT.kLHintsLeft,10,10,0,10))
	self.CalLevel_Dispersion_Code = ROOT.TGNumberEntry(self.CalLevelFrame4a, 512,9,999,ROOT.TGNumberFormat.kNESInteger ,ROOT.TGNumberFormat.kNEANonNegative, ROOT.TGNumberFormat.kNELLimitMinMax, 1 , 1023 );
        self.CalLevelFrame4a.AddFrame(self.CalLevel_Dispersion_Code,ROOT.TGLayoutHints(ROOT.kLHintsExpandX|ROOT.kLHintsExpandY,10,10,0,10))

	self.CalLevelFrame4b = ROOT.TGHorizontalFrame (self.CalLevelFrame2 )
	self.CalLevel_Dispersion_Measurements_Label = ROOT.TGLabel ( self.CalLevelFrame4b, " Measur. " )
	self.CalLevelFrame4b.AddFrame(self.CalLevel_Dispersion_Measurements_Label, ROOT.TGLayoutHints(ROOT.kLHintsTop|ROOT.kLHintsLeft,10,10,0,0))
	self.CalLevel_Dispersion_Measurements = ROOT.TGNumberEntry(self.CalLevelFrame4b, 10,9,999,ROOT.TGNumberFormat.kNESInteger ,ROOT.TGNumberFormat.kNEANonNegative, ROOT.TGNumberFormat.kNELLimitMinMax, 1 , 200 );
        self.CalLevelFrame4b.AddFrame(self.CalLevel_Dispersion_Measurements,ROOT.TGLayoutHints(ROOT.kLHintsExpandX|ROOT.kLHintsExpandY,20,10,0,0))

	
	self.DAC_Gaus_Calibration_Button = ROOT.TGTextButton( self.CalLevelFrame2 ,"  Gaus Calibration  ")
	self.Do_DAC_Gaus_Calibration = ROOT.TPyDispatcher( self.DAC_Gaus_Calibration) # this command translate the python command in C++ launguage I think
	self.DAC_Gaus_Calibration_Button.Connect('Clicked()' , 'TPyDispatcher' , self.Do_DAC_Gaus_Calibration,'Dispatch()')


	self.CalLevelFrame5a = ROOT.TGHorizontalFrame (self.CalLevelFrame2 )
	self.DAC_Gaus_Calibration_Measurements_Label = ROOT.TGLabel ( self.CalLevelFrame5a, " Measurements  " )
	self.CalLevelFrame5a.AddFrame(self.DAC_Gaus_Calibration_Measurements_Label,ROOT.TGLayoutHints(ROOT.kLHintsTop|ROOT.kLHintsLeft,3,10,10,10))
	self.DAC_Gaus_Calibration_Measurements = ROOT.TGNumberEntry(self.CalLevelFrame5a, 20,9,999,ROOT.TGNumberFormat.kNESInteger ,ROOT.TGNumberFormat.kNEANonNegative, ROOT.TGNumberFormat.kNELLimitMinMax, 10 , 200 );
        self.CalLevelFrame5a.AddFrame(self.DAC_Gaus_Calibration_Measurements , ROOT.TGLayoutHints(ROOT.kLHintsExpandX|ROOT.kLHintsExpandY,0,10,10,10))

	self.CalLevelFrame5b = ROOT.TGHorizontalFrame (self.CalLevelFrame2 )
	self.DAC_Gaus_Calibration_Points_Label = ROOT.TGLabel ( self.CalLevelFrame5b, " Num. of points " )
	self.CalLevelFrame5b.AddFrame(self.DAC_Gaus_Calibration_Points_Label,ROOT.TGLayoutHints(ROOT.kLHintsTop|ROOT.kLHintsLeft,3,10,0,10))
	self.DAC_Gaus_Calibration_Points = ROOT.TGNumberEntry(self.CalLevelFrame5b, 20,9,999,ROOT.TGNumberFormat.kNESInteger ,ROOT.TGNumberFormat.kNEANonNegative, ROOT.TGNumberFormat.kNELLimitMinMax, 5 , 1023 );
        self.CalLevelFrame5b.AddFrame(self.DAC_Gaus_Calibration_Points , ROOT.TGLayoutHints(ROOT.kLHintsExpandX|ROOT.kLHintsExpandY,0,10,0,10))


	self.CalLevelFrame2.AddFrame(self.CalLevelFrame4a, ROOT.TGLayoutHints(ROOT.kLHintsTop|ROOT.kLHintsLeft, 10,10,0,5))
	self.CalLevelFrame2.AddFrame(self.CalLevelFrame4b, ROOT.TGLayoutHints(ROOT.kLHintsTop|ROOT.kLHintsLeft, 10,10,0,10))

	self.CalLevelFrame2.AddFrame(self.DAC_Gaus_Calibration_Button, ROOT.TGLayoutHints(ROOT.kLHintsTop|ROOT.kLHintsLeft,50,10,10,10))
	self.CalLevelFrame2.AddFrame(self.CalLevelFrame5a, ROOT.TGLayoutHints(ROOT.kLHintsTop|ROOT.kLHintsLeft, 0,10,0,10))
	self.CalLevelFrame2.AddFrame(self.CalLevelFrame5b, ROOT.TGLayoutHints(ROOT.kLHintsTop|ROOT.kLHintsLeft, 0,10,0,10))


	self.CalLevelFrame1.AddFrame(self.CalLevelFrame2, ROOT.TGLayoutHints(ROOT.kLHintsTop|ROOT.kLHintsLeft, 10,10,0,10))


	self.tabA.AddFrame(self.CalLevelFrame1, ROOT.TGLayoutHints(ROOT.kLHintsTop|ROOT.kLHintsLeft, 10,10,10,10))


	#### DNL DAC tab ####

	self.DNLFrame1 = ROOT.TGHorizontalFrame (self.tabB )
	self.Canvas_DNL  = ROOT.TRootEmbeddedCanvas( 'DNL', self.DNLFrame1, 600, 500 )
	self.DNLFrame1.AddFrame(self.Canvas_DNL, ROOT.TGLayoutHints(ROOT.kLHintsTop|ROOT.kLHintsLeft, 10, 5, 0, 5))  

	self.DNLFrame2 = ROOT.TGVerticalFrame( self.DNLFrame1 )

	self.DNLButton = ROOT.TGTextButton( self.DNLFrame2 ,"   DNL   ")
	self.Do_DNL = ROOT.TPyDispatcher( self.DNL ) # this command translate the python command in C++ launguage I think
	self.DNLButton.Connect('Clicked()' , 'TPyDispatcher' , self.Do_DNL,'Dispatch()')
	self.DNLFrame2.AddFrame(self.DNLButton, ROOT.TGLayoutHints(ROOT.kLHintsTop|ROOT.kLHintsLeft,50,10,0,10))
	"""
	self.DNLSTOPButton = ROOT.TGTextButton( self.VThFrame2 ,"   STOP   ")
	self.Do_STOP_Button = ROOT.TPyDispatcher( self.STOP_Button) # this command translate the python command in C++ launguage I think
	self.DNLSTOPButton.Connect('Clicked()' , 'TPyDispatcher' , self.Do_STOP_Button,'Dispatch()')
	self.DNLFrame2.AddFrame(self.VThSTOPButton, ROOT.TGLayoutHints(ROOT.kLHintsTop|ROOT.kLHintsLeft,50,10,0,10))
	
	self.DNLFITButton = ROOT.TGTextButton( self.VThFrame2 ,"   FIT   ")
	#self.Do_FIT = ROOT.TPyDispatcher( self.FIT) # this command translate the python command in C++ launguage I think
	#self.DNLFITButton.Connect('Clicked()' , 'TPyDispatcher' , self.Do_FIT,'Dispatch()')
	self.DNLFrame2.AddFrame(self.VThFITButton, ROOT.TGLayoutHints(ROOT.kLHintsTop|ROOT.kLHintsLeft,50,10,0,10))
	"""
	self.DNL_FitRange_Label = ROOT.TGLabel ( self.DNLFrame2, " Linear Fit Range " )
	self.DNLFrame2.AddFrame(self.DNL_FitRange_Label, ROOT.TGLayoutHints(ROOT.kLHintsTop|ROOT.kLHintsLeft,50,10,10,10))

	self.DNLFrame3a = ROOT.TGHorizontalFrame (self.DNLFrame2 )
	self.DNL_FitRange_Label_Min = ROOT.TGLabel ( self.DNLFrame3a, " Min " )
	self.DNLFrame3a.AddFrame(self.DNL_FitRange_Label_Min, ROOT.TGLayoutHints(ROOT.kLHintsTop|ROOT.kLHintsLeft,10,10,0,0))
	self.DNL_FitRange_Min = ROOT.TGNumberEntry(self.DNLFrame3a, 1,9,999,ROOT.TGNumberFormat.kNESInteger ,ROOT.TGNumberFormat.kNEANonNegative, ROOT.TGNumberFormat.kNELLimitMinMax, 1 , 1023 );
        self.DNLFrame3a.AddFrame(self.DNL_FitRange_Min,ROOT.TGLayoutHints(ROOT.kLHintsExpandX|ROOT.kLHintsExpandY,10,10,0,0))
	
	self.DNLFrame2.AddFrame(self.DNLFrame3a, ROOT.TGLayoutHints(ROOT.kLHintsTop|ROOT.kLHintsLeft, 10,10,0,5))
	
	self.DNLFrame3b = ROOT.TGHorizontalFrame (self.DNLFrame2 )
	self.DNL_FitRange_Label_Max = ROOT.TGLabel ( self.DNLFrame3b, " Max" )
	self.DNLFrame3b.AddFrame(self.DNL_FitRange_Label_Max, ROOT.TGLayoutHints(ROOT.kLHintsTop|ROOT.kLHintsLeft,10,10,0,10))
	self.DNL_FitRange_Max = ROOT.TGNumberEntry(self.DNLFrame3b, 1023,9,999,ROOT.TGNumberFormat.kNESInteger ,ROOT.TGNumberFormat.kNEANonNegative, ROOT.TGNumberFormat.kNELLimitMinMax, 1 , 1023 );
        self.DNLFrame3b.AddFrame(self.DNL_FitRange_Max,ROOT.TGLayoutHints(ROOT.kLHintsExpandX|ROOT.kLHintsExpandY,10,10,0,10))

	self.DNLFrame2.AddFrame(self.DNLFrame3b, ROOT.TGLayoutHints(ROOT.kLHintsTop|ROOT.kLHintsLeft, 10,10,0,0))
	
	
	"""
	self.DNL_Dispersion_Button = ROOT.TGTextButton( self.VThFrame2 ,"  Dispersion of Measurments   ")
	self.Do_Dispersion_DNL = ROOT.TPyDispatcher( self.VTh_Dispersion) # this command translate the python command in C++ launguage I think
	self.DNL_Dispersion_Button.Connect('Clicked()' , 'TPyDispatcher' , self.Do_Dispersion_VTh,'Dispatch()')
	self.DNLFrame2.AddFrame(self.VTh_Dispersion_Button, ROOT.TGLayoutHints(ROOT.kLHintsTop|ROOT.kLHintsLeft,30,10,10,10))
	
	self.DNLFrame4a = ROOT.TGHorizontalFrame (self.VThFrame2 )
	self.DNL_Dispersion_Code_Label = ROOT.TGLabel ( self.VThFrame4a, " DAC Code" )
	self.DNLFrame4a.AddFrame(self.VTh_Dispersion_Code_Label, ROOT.TGLayoutHints(ROOT.kLHintsTop|ROOT.kLHintsLeft,10,10,0,10))
	self.DNL_Dispersion_Code = ROOT.TGNumberEntry(self.VThFrame4a, 512,9,999,ROOT.TGNumberFormat.kNESInteger ,ROOT.TGNumberFormat.kNEANonNegative, ROOT.TGNumberFormat.kNELLimitMinMax, 1 , 1023 );
        self.DNLFrame4a.AddFrame(self.VTh_Dispersion_Code,ROOT.TGLayoutHints(ROOT.kLHintsExpandX|ROOT.kLHintsExpandY,10,10,0,10))

	self.DNLFrame4b = ROOT.TGHorizontalFrame (self.VThFrame2 )
	self.DNL_Dispersion_Measurements_Label = ROOT.TGLabel ( self.VThFrame4b, " Measur. " )
	self.DNLFrame4b.AddFrame(self.VTh_Dispersion_Measurements_Label, ROOT.TGLayoutHints(ROOT.kLHintsTop|ROOT.kLHintsLeft,10,10,0,0))
	self.DNL_Dispersion_Measurements = ROOT.TGNumberEntry(self.VThFrame4b, 10,9,999,ROOT.TGNumberFormat.kNESInteger ,ROOT.TGNumberFormat.kNEANonNegative, ROOT.TGNumberFormat.kNELLimitMinMax, 1 , 200 );
        self.DNLFrame4b.AddFrame(self.VTh_Dispersion_Measurements,ROOT.TGLayoutHints(ROOT.kLHintsExpandX|ROOT.kLHintsExpandY,20,10,0,0))
	
	self.DNLFrame2.AddFrame(self.VThFrame4a, ROOT.TGLayoutHints(ROOT.kLHintsTop|ROOT.kLHintsLeft, 10,10,0,5))
	self.DNLFrame2.AddFrame(self.VThFrame4b, ROOT.TGLayoutHints(ROOT.kLHintsTop|ROOT.kLHintsLeft, 10,10,0,10))
	"""


	self.DNLFrame1.AddFrame(self.DNLFrame2, ROOT.TGLayoutHints(ROOT.kLHintsTop|ROOT.kLHintsLeft, 10,10,0,10))


	self.tabB.AddFrame(self.DNLFrame1, ROOT.TGLayoutHints(ROOT.kLHintsTop|ROOT.kLHintsLeft, 10,10,10,10))

	
