import ROOT
import math
import hmac
import hashlib
import sys,socket
import os
from os.path import exists
import string
import time
import MESSAGES
import datetime

def ReadADC_Ex(self):

	t = 0.0004

        self.send_message(MESSAGES.MESSAGE4)  # the sent message starts the ADC

	time.sleep(t)

        self.received_message()

	self.send_message(MESSAGES.MESSAGE5)  # the sent message reads the ADC

        time.sleep(t)

        measurment = self.received_message()
	
	measurment = self.Read_HexToBin(measurment) # convert the HEX message in a list, each component of the list is a bit written as a string

	measurment = string.join(measurment)

        measurment = ''.join(measurment.split())


	ADCValue = int(measurment, 2)  # convert the binary number in a decimal number 
	
	#print dec

	self.ReadADCValue.SetText(str(ADCValue)) # print the number on the label " Reading ADC " in the ADC tab

def ADC_Calibration_Ex(self):
	
	data = datetime.datetime.now()
		
	my_time_minute = str(data.minute)
	my_time_hour = str(data.hour)
	my_day = str(data.day)
	my_month = str(data.month)
	my_year = str(data.year)
	

	filename = ["ADC_Calibration"]
	filename.append(my_time_hour)
	filename.append(my_time_minute)
	filename.append(my_day)
	filename.append(my_month)
	filename.append(my_year)
 	filename.insert(0,"CHIPIX_response_board/")
	filename.append('.root')
	filename = string.join(filename)
	filename = filename.replace(" ","_")
	filename = filename.replace("2017_.root","2017.root")

	export_file = ROOT.TFile(filename,"RECREATE")	
	self.STOP = 0

	cvs = self.Canvas_ADC.GetCanvas()

	cvs.cd(0)

	gr = ROOT.TGraphErrors(4096)

	gr.Draw("AP") # if you write "ALP" draw a line from the first to last and go back

	gr.SetMarkerStyle(21)

	gr.SetMarkerSize(0.4)

	gr.GetXaxis().SetTitle(" mV")

	gr.GetYaxis().SetTitle(" ADC code " )

	gr.SetTitle("ADC Calibration ")
	
	t = 0.001
	
	self.Mon_Moux_Select(28)
	self.Connect_Keithley()

	self.Volt = []
	self.ADC_code = []
	
	#input number ('valori di tensione')

	number = 4100
	g = 1000.0/number
        for x in range(number):
		
		time.sleep(0.05)
	
		tension = g*x

		#print tension

		self.Volt_Source_Keithley(tension)

		a = []
		
		for u in range(4):

			self.send_message(MESSAGES.MESSAGE4)  # the sent message starts the ADC

			time.sleep(t)

        		self.received_message()

			self.send_message(MESSAGES.MESSAGE5)  # the sent message reads the ADC

        		time.sleep(t)

        		measurment = self.received_message()
	
			measurment = self.Read_HexToBin(measurment) # convert the HEX message in a list, each component of the list is a bit written as a string


			measurment = string.join(measurment)

        		measurment = ''.join(measurment.split())

			ADCValue = int(measurment, 2)  # convert the binary number in a decimal number 
			#print ADCValue
			a.append(ADCValue)

		mean = (a[0]+a[1]+a[2]+a[3])/4.0
		
		RMS = 0
			
		RMS = RMS +  (mean - a[0])*(mean-a[0])
		RMS = RMS +  (mean - a[1])*(mean-a[1])
		RMS = RMS +  (mean - a[2])*(mean-a[2])
		RMS = RMS +  (mean - a[3])*(mean-a[3])

		err = math.sqrt(RMS/3) # 3 = N - 1
		self.ADC_code.append(mean)
		
		gr.SetPoint(x+1,tension,mean)
		gr.SetPointError(x+1,0,err)
	
		ROOT.gPad.Modified()
		ROOT.gPad.Update()

		if self.STOP == 1:
			break
	gr.Write()
	export_file.Close()

	self.Volt_Source_Keithley(0)  
	print "ciao"
