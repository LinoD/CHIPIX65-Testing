

import ROOT

"""
if DAC_numb == 1:
		filename  = ["CAL_LEVEL_DAC"]
	elif DAC_numb == 2:
		filename = ["ICTRL"]
	elif DAC_numb == 3:
		filename = ["VTH"]
	elif DAC_numb == 4:
		filename = ["VBL"]
	elif DAC_numb == 5:
		filename = ["BIASP1"]
	elif DAC_numb == 6:
		filename = ["BIASP2"]
	elif DAC_numb == 7:
		filename = ["DISC"]
	elif DAC_numb == 8:
		filename = ["BIAS_SF"]
	elif DAC_numb == 9:
		filename = ["VRef_KRUM"]
	elif DAC_numb == 10:
		filename = ["BIAS_FEED"]
"""

def LOOP_Ex(self):

	self.reset_Button()
	self.DAC_Gaus_Calibration_Measurements.SetNumber(100)
	self.DAC_Gaus_Calibration_Points.SetNumber(1023)


	self.DAC_Mux.SetNumber(1)
	self.Mux()
	self.CalLevel_ComboBox.Select(2,ROOT.kTRUE)
	combo_selected = self.CalLevel_ComboBox.GetSelected () 
	print combo_selected
	self.DAC_Gaus_Calibration()
	
	self.reset_Button
	
	
	self.CalLevel_ComboBox.Select(3,ROOT.kTRUE)
	combo_selected = self.CalLevel_ComboBox.GetSelected () 
	print combo_selected
	self.DAC_Gaus_Calibration()

	self.reset_Button()

	self.CalLevel_ComboBox.Select(4,ROOT.kTRUE)
	combo_selected = self.CalLevel_ComboBox.GetSelected () 
	print combo_selected
	self.DAC_Gaus_Calibration()

	self.reset_Button()
	
	self.ADC_Code_Density()
	
