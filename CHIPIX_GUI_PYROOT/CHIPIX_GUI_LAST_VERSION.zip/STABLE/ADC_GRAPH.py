import ROOT

def ADCGraphEx(self):

	self.ADC1 = ROOT.TGHorizontalFrame( self.tab4 )

	self.ReadADCButton = ROOT.TGTextButton( self.ADC1 ,"   Read ADC   ")
      	self.Do_ReadADC = ROOT.TPyDispatcher( self.ReadADC ) # this command translate the python command in C++ launguage I think
	self.ReadADCButton.Connect('Clicked()' , 'TPyDispatcher' , self.Do_ReadADC, 'Dispatch()')
	self.ADC1.AddFrame(self.ReadADCButton, ROOT.TGLayoutHints(ROOT.kLHintsTop|ROOT.kLHintsLeft, 10,10,10,10))


	self.ReadADCLabel= ROOT.TGLabel(self.ADC1, "ADC reading")
        self.ADC1.AddFrame(self.ReadADCLabel, ROOT.TGLayoutHints(ROOT.kLHintsTop|ROOT.kLHintsLeft,40,2,12,10))


        self.ReadADCValue = ROOT.TGLabel(self.ADC1, "            " )
	self.ReadADCValue.SetForegroundColor(234)
	#self.ReadADCValue.SetBackgroundColor (ROOT.kWhite)

        self.ADC1.AddFrame(self.ReadADCValue,ROOT.TGLayoutHints(ROOT.kLHintsExpandX|ROOT.kLHintsExpandY,10,2,12,10))

	self.tab4.AddFrame(self.ADC1,ROOT.TGLayoutHints(ROOT.kLHintsTop|ROOT.kLHintsLeft, 10,10,10,10))


	
	self.ADC2 = ROOT.TGHorizontalFrame( self.tab4 )
	
	self.tabsFrameADC = ROOT.TGTab(self.ADC2, 650, 200)
       	self.tabsFrameADC.DrawBorder()

	self.tabA1 = self.tabsFrameADC.AddTab("  Calibration   ") # **NOTE! Each tab is now a ROOT.TGCompositeFrame object

        self.tabB2 = self.tabsFrameADC.AddTab("  Code Density   ") # **NOTE! Each tab is now a ROOT.TGCompositeFrame object

        self.tabC3 = self.tabsFrameADC.AddTab("  ?   ") # **NOTE! Each tab is now a ROOT.TGCompositeFrame object

	self.tabD4 = self.tabsFrameADC.AddTab("  ?   ") # **NOTE! Each tab is now a ROOT.TGCompositeFrame object
		
	self.tabE5 = self.tabsFrameADC.AddTab("  ?   ") 

                # ad the Tabs to the Frame

       


	#### ADC CALIBRATION tab ####

	self.ADCFrame1 = ROOT.TGHorizontalFrame (self.tabA1)
	self.Canvas_ADC  = ROOT.TRootEmbeddedCanvas( 'ADC Calibration', self.ADCFrame1, 600, 450 )
	self.ADCFrame1.AddFrame(self.Canvas_ADC, ROOT.TGLayoutHints(ROOT.kLHintsTop|ROOT.kLHintsLeft, 10, 5, 0, 5))  

	self.ADCFrame2 = ROOT.TGVerticalFrame( self.ADCFrame1 )

	self.ADCButton = ROOT.TGTextButton( self.ADCFrame2 ,"   Calibrate ADC   ")
	self.Do_ADC = ROOT.TPyDispatcher( self.ADC_Calibration ) # this command translate the python command in C++ launguage I think
	self.ADCButton.Connect('Clicked()' , 'TPyDispatcher' , self.Do_ADC,'Dispatch()')
	self.ADCFrame2.AddFrame(self.ADCButton, ROOT.TGLayoutHints(ROOT.kLHintsTop|ROOT.kLHintsLeft,50,10,0,10))
	
	self.ADCSTOPButton = ROOT.TGTextButton( self.ADCFrame2 ,"   STOP   ")
	self.Do_STOP_ADC_Button = ROOT.TPyDispatcher( self.STOP_Button) # this command translate the python command in C++ launguage I think
	self.ADCSTOPButton.Connect('Clicked()' , 'TPyDispatcher' , self.Do_STOP_ADC_Button,'Dispatch()')
	self.ADCFrame2.AddFrame(self.ADCSTOPButton, ROOT.TGLayoutHints(ROOT.kLHintsTop|ROOT.kLHintsLeft,50,10,10,10))
	
	self.ADCFITButton = ROOT.TGTextButton( self.ADCFrame2 ,"   FIT   ")
	#self.Do_FIT = ROOT.TPyDispatcher( self.FIT) # this command translate the python command in C++ launguage I think
	#self.ADCFITButton.Connect('Clicked()' , 'TPyDispatcher' , self.Do_FIT,'Dispatch()')
	self.ADCFrame2.AddFrame(self.ADCFITButton, ROOT.TGLayoutHints(ROOT.kLHintsTop|ROOT.kLHintsLeft,50,10,10,10))

	self.ADCFrame3a = ROOT.TGHorizontalFrame (self.ADCFrame2 )
	self.ADC_FitRange_Label_Min = ROOT.TGLabel ( self.ADCFrame3a, " Min " )
	self.ADCFrame3a.AddFrame(self.ADC_FitRange_Label_Min, ROOT.TGLayoutHints(ROOT.kLHintsTop|ROOT.kLHintsLeft,10,10,0,0))
	self.ADC_FitRange_Min = ROOT.TGNumberEntry(self.ADCFrame3a, 1,9,999,ROOT.TGNumberFormat.kNESInteger ,ROOT.TGNumberFormat.kNEANonNegative, ROOT.TGNumberFormat.kNELLimitMinMax, 1 , 1023 );
        self.ADCFrame3a.AddFrame(self.ADC_FitRange_Min,ROOT.TGLayoutHints(ROOT.kLHintsExpandX|ROOT.kLHintsExpandY,10,10,0,0))
	
	self.ADCFrame2.AddFrame(self.ADCFrame3a, ROOT.TGLayoutHints(ROOT.kLHintsTop|ROOT.kLHintsLeft, 10,10,0,5))
	
	self.ADCFrame3b = ROOT.TGHorizontalFrame (self.ADCFrame2 )
	self.ADC_FitRange_Label_Max = ROOT.TGLabel ( self.ADCFrame3b, " Max" )
	self.ADCFrame3b.AddFrame(self.ADC_FitRange_Label_Max, ROOT.TGLayoutHints(ROOT.kLHintsTop|ROOT.kLHintsLeft,10,10,0,10))
	self.ADC_FitRange_Max = ROOT.TGNumberEntry(self.ADCFrame3b, 4095,9,999,ROOT.TGNumberFormat.kNESInteger ,ROOT.TGNumberFormat.kNEANonNegative, ROOT.TGNumberFormat.kNELLimitMinMax, 1 , 4095 );
        self.ADCFrame3b.AddFrame(self.ADC_FitRange_Max,ROOT.TGLayoutHints(ROOT.kLHintsExpandX|ROOT.kLHintsExpandY,10,10,0,10))

	self.ADCFrame2.AddFrame(self.ADCFrame3b, ROOT.TGLayoutHints(ROOT.kLHintsTop|ROOT.kLHintsLeft, 10,10,0,0))
	
	
	
	self.ADC_Settings_Label = ROOT.TGLabel( self.ADCFrame2 ,"  Calibration Settings   ")
	self.ADCFrame2.AddFrame(self.ADC_Settings_Label, ROOT.TGLayoutHints(ROOT.kLHintsTop|ROOT.kLHintsLeft,20,10,30,30))

	self.ADCFrame4a = ROOT.TGHorizontalFrame (self.ADCFrame2 )
	self.ADC_Calibration_Tension_Min_Label = ROOT.TGLabel ( self.ADCFrame4a, " Tension Min" )
	self.ADCFrame4a.AddFrame(self.ADC_Calibration_Tension_Min_Label, ROOT.TGLayoutHints(ROOT.kLHintsTop|ROOT.kLHintsLeft,0,10,0,10))
	self.ADC_Calibration_Tension_Min = ROOT.TGNumberEntry(self.ADCFrame4a, 0,9,999,ROOT.TGNumberFormat.kNESInteger ,ROOT.TGNumberFormat.kNEANonNegative, ROOT.TGNumberFormat.kNELLimitMinMax, 0 , 1000 );   

	self.ADCFrame4a.AddFrame(self.ADC_Calibration_Tension_Min, ROOT.TGLayoutHints(ROOT.kLHintsExpandX|ROOT.kLHintsExpandY,10,10,0,10))

	self.ADCFrame4b = ROOT.TGHorizontalFrame (self.ADCFrame2 )
	self.ADC_Calibration_Tension_Max_Label = ROOT.TGLabel ( self.ADCFrame4b, " Tension Max" )
	self.ADCFrame4b.AddFrame(self.ADC_Calibration_Tension_Max_Label, ROOT.TGLayoutHints(ROOT.kLHintsTop|ROOT.kLHintsLeft,0,10,0,0))
	self.ADC_Calibration_Tension_Max = ROOT.TGNumberEntry(self.ADCFrame4b, 1000,9,999,ROOT.TGNumberFormat.kNESInteger ,ROOT.TGNumberFormat.kNEANonNegative, ROOT.TGNumberFormat.kNELLimitMinMax, 1 , 1000 );
        self.ADCFrame4b.AddFrame(self.ADC_Calibration_Tension_Max,ROOT.TGLayoutHints(ROOT.kLHintsExpandX|ROOT.kLHintsExpandY,10,10,0,0))


	self.ADCFrame5b = ROOT.TGHorizontalFrame (self.ADCFrame2 )
	self.ADC_Calibration_Points_Label = ROOT.TGLabel ( self.ADCFrame5b, " Num. of points " )
	self.ADCFrame5b.AddFrame(self.ADC_Calibration_Points_Label,ROOT.TGLayoutHints(ROOT.kLHintsTop|ROOT.kLHintsLeft,0,10,0,10))
	self.ADC_Calibration_Points = ROOT.TGNumberEntry(self.ADCFrame5b, 100,9,999,ROOT.TGNumberFormat.kNESInteger ,ROOT.TGNumberFormat.kNEANonNegative, ROOT.TGNumberFormat.kNELLimitMinMax, 5 , 10000 )
	self.ADCFrame5b.AddFrame(self.ADC_Calibration_Points , ROOT.TGLayoutHints(ROOT.kLHintsExpandX|ROOT.kLHintsExpandY,10,10,0,10))


	self.ADCFrame2.AddFrame(self.ADCFrame4a, ROOT.TGLayoutHints(ROOT.kLHintsTop|ROOT.kLHintsLeft, 0,10,0,5))
	self.ADCFrame2.AddFrame(self.ADCFrame4b, ROOT.TGLayoutHints(ROOT.kLHintsTop|ROOT.kLHintsLeft, 0,10,0,10))

	self.ADCFrame2.AddFrame(self.ADCFrame5b, ROOT.TGLayoutHints(ROOT.kLHintsTop|ROOT.kLHintsLeft, 0,10,0,10))


	self.ADCFrame1.AddFrame(self.ADCFrame2, ROOT.TGLayoutHints(ROOT.kLHintsTop|ROOT.kLHintsLeft, 10,10,0,10))

	self.tabA1.AddFrame(self.ADCFrame1,ROOT.TGLayoutHints(ROOT.kLHintsTop|ROOT.kLHintsLeft, 10,10,10,10)) 
 
        #self.ADC2.AddFrame(self.tabsFrameADC,ROOT.TGLayoutHints(ROOT.kLHintsExpandX|ROOT.kLHintsExpandY,10,10,0,0) )
	


	##### Code Density tab ####

	self.ADC_Code_DensityFrame1 = ROOT.TGHorizontalFrame (self.tabB2)
	self.Canvas_ADC_Code_Density  = ROOT.TRootEmbeddedCanvas( 'Code Density', self.ADC_Code_DensityFrame1, 600, 450 )
	self.ADC_Code_DensityFrame1.AddFrame(self.Canvas_ADC_Code_Density, ROOT.TGLayoutHints(ROOT.kLHintsTop|ROOT.kLHintsLeft, 10, 5, 0, 5))  

	self.ADC_Code_DensityFrame2 = ROOT.TGVerticalFrame( self.ADC_Code_DensityFrame1 )

	self.ADC_Code_DensityButton = ROOT.TGTextButton( self.ADC_Code_DensityFrame2 ,"  ADC Code Density   ")
	self.Do_ADC_Code_Density = ROOT.TPyDispatcher( self.ADC_Code_Density ) # this command translate the python command in C++ launguage I think
	self.ADC_Code_DensityButton.Connect('Clicked()' , 'TPyDispatcher' , self.Do_ADC_Code_Density,'Dispatch()')
	self.ADC_Code_DensityFrame2.AddFrame(self.ADC_Code_DensityButton, ROOT.TGLayoutHints(ROOT.kLHintsTop|ROOT.kLHintsLeft,50,10,0,10))
	
	self.ADC_Code_DensitySTOPButton = ROOT.TGTextButton( self.ADC_Code_DensityFrame2 ,"   STOP   ")
	self.Do_STOP_Code_Density_Button = ROOT.TPyDispatcher( self.STOP_Button) # this command translate the python command in C++ launguage I think
	self.ADC_Code_DensitySTOPButton.Connect('Clicked()' , 'TPyDispatcher' , self.Do_STOP_Code_Density_Button,'Dispatch()')
	self.ADC_Code_DensityFrame2.AddFrame(self.ADC_Code_DensitySTOPButton, ROOT.TGLayoutHints(ROOT.kLHintsTop|ROOT.kLHintsLeft,50,10,10,10))
	

	self.ADC_Code_Density_Settings_Label = ROOT.TGLabel( self.ADC_Code_DensityFrame2 ,"  Calibration Settings   ")
	self.ADC_Code_DensityFrame2.AddFrame(self.ADC_Code_Density_Settings_Label, ROOT.TGLayoutHints(ROOT.kLHintsTop|ROOT.kLHintsLeft,20,10,30,30))

	self.ADC_Code_DensityFrame4a = ROOT.TGHorizontalFrame (self.ADC_Code_DensityFrame2 )
	self.ADC_Code_Density_Calibration_Tension_Min_Label = ROOT.TGLabel ( self.ADC_Code_DensityFrame4a, " Tension Min" )
	self.ADC_Code_DensityFrame4a.AddFrame(self.ADC_Code_Density_Calibration_Tension_Min_Label, ROOT.TGLayoutHints(ROOT.kLHintsTop|ROOT.kLHintsLeft,10,10,0,10))
	self.ADC_Code_Density_Calibration_Tension_Min = ROOT.TGNumberEntry(self.ADC_Code_DensityFrame4a, 0,9,999,ROOT.TGNumberFormat.kNESInteger ,ROOT.TGNumberFormat.kNEANonNegative, ROOT.TGNumberFormat.kNELLimitMinMax, 0 , 1000 );   

	self.ADC_Code_DensityFrame4a.AddFrame(self.ADC_Code_Density_Calibration_Tension_Min, ROOT.TGLayoutHints(ROOT.kLHintsExpandX|ROOT.kLHintsExpandY,10,10,0,10))

	self.ADC_Code_DensityFrame4b = ROOT.TGHorizontalFrame (self.ADC_Code_DensityFrame2 )
	self.ADC_Code_Density_Calibration_Tension_Max_Label = ROOT.TGLabel ( self.ADC_Code_DensityFrame4b, " Tension Max" )
	self.ADC_Code_DensityFrame4b.AddFrame(self.ADC_Code_Density_Calibration_Tension_Max_Label, ROOT.TGLayoutHints(ROOT.kLHintsTop|ROOT.kLHintsLeft,10,10,0,0))
	self.ADC_Code_Density_Calibration_Tension_Max = ROOT.TGNumberEntry(self.ADC_Code_DensityFrame4b, 1000,9,999,ROOT.TGNumberFormat.kNESInteger ,ROOT.TGNumberFormat.kNEANonNegative, ROOT.TGNumberFormat.kNELLimitMinMax, 1 , 900 ); 

	self.ADC_Code_DensityFrame4b.AddFrame(self.ADC_Code_Density_Calibration_Tension_Max,ROOT.TGLayoutHints(ROOT.kLHintsExpandX|ROOT.kLHintsExpandY,10,10,0,0))


	self.ADC_Code_DensityFrame5b = ROOT.TGHorizontalFrame (self.ADC_Code_DensityFrame2 )
	self.ADC_Code_Density_Tension_Step_Label = ROOT.TGLabel ( self.ADC_Code_DensityFrame5b, "Step microV")
	self.ADC_Code_DensityFrame5b.AddFrame(self.ADC_Code_Density_Tension_Step_Label, ROOT.TGLayoutHints(ROOT.kLHintsTop|ROOT.kLHintsLeft,10,10,0,10))
	self.ADC_Code_Density_Tension_Step = ROOT.TGNumberEntry(self.ADC_Code_DensityFrame5b, 5,9,999,ROOT.TGNumberFormat.kNESInteger ,ROOT.TGNumberFormat.kNEANonNegative, ROOT.TGNumberFormat.kNELLimitMinMax, 0 , 1000 );
        self.ADC_Code_DensityFrame5b.AddFrame(self.ADC_Code_Density_Tension_Step , ROOT.TGLayoutHints(ROOT.kLHintsExpandX|ROOT.kLHintsExpandY,0,10,0,10))


	self.ADC_Code_DensityFrame2.AddFrame(self.ADC_Code_DensityFrame4a, ROOT.TGLayoutHints(ROOT.kLHintsTop|ROOT.kLHintsLeft, 0,10,0,5))
	self.ADC_Code_DensityFrame2.AddFrame(self.ADC_Code_DensityFrame4b, ROOT.TGLayoutHints(ROOT.kLHintsTop|ROOT.kLHintsLeft, 0,10,0,10))

	self.ADC_Code_DensityFrame2.AddFrame(self.ADC_Code_DensityFrame5b, ROOT.TGLayoutHints(ROOT.kLHintsTop|ROOT.kLHintsLeft, 0,10,0,10))


	self.ADC_Code_DensityFrame1.AddFrame(self.ADC_Code_DensityFrame2, ROOT.TGLayoutHints(ROOT.kLHintsTop|ROOT.kLHintsLeft, 10,10,0,10))

	self.tabB2.AddFrame(self.ADC_Code_DensityFrame1,ROOT.TGLayoutHints(ROOT.kLHintsTop|ROOT.kLHintsLeft, 10,10,10,10)) 
 
        self.ADC2.AddFrame(self.tabsFrameADC,ROOT.TGLayoutHints(ROOT.kLHintsExpandX|ROOT.kLHintsExpandY,10,10,0,0) )
	
	self.tab4.AddFrame(self.ADC2,ROOT.TGLayoutHints(ROOT.kLHintsTop|ROOT.kLHintsLeft, 10,10,0,10))          


