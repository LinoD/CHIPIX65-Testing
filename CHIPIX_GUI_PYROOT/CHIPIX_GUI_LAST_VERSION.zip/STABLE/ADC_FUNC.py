import ROOT
import math
import hmac
import hashlib
import sys,socket
import os
from os.path import exists
import string
import time
import MESSAGES
import datetime

def ReadADC_Ex(self):

	t = 0.0004

        self.send_message(MESSAGES.MESSAGE4)  # the sent message starts the ADC

	time.sleep(t)

        self.received_message()

	self.send_message(MESSAGES.MESSAGE5)  # the sent message reads the ADC

        time.sleep(t)

        measurment = self.received_message()
	
	measurment = self.Read_HexToBin(measurment) # convert the HEX message in a list, each component of the list is a bit written as a string

	measurment = string.join(measurment)

        measurment = ''.join(measurment.split())


	ADCValue = int(measurment, 2)  # convert the binary number in a decimal number 
	
	#print dec

	self.ReadADCValue.SetText(str(ADCValue)) # print the number on the label " Reading ADC " in the ADC tab

def ADC_Calibration_Ex(self):
	
	data = datetime.datetime.now()
		
	my_time_minute = str(data.minute)
	my_time_hour = str(data.hour)
	my_day = str(data.day)
	my_month = str(data.month)
	my_year = str(data.year)
	

	filename = ["ADC_Calibration"]
	filename.append(my_time_hour)
	filename.append(my_time_minute)
	filename.append(my_day)
	filename.append(my_month)
	filename.append(my_year)
 	filename.insert(0,"CHIPIX_response_board/")
	filename.append('.root')
	filename = string.join(filename)
	filename = filename.replace(" ","_")
	filename = filename.replace("2017_.root","2017.root")

	export_file = ROOT.TFile(filename,"RECREATE")	
	
	self.STOP = 0

	cvs = self.Canvas_ADC.GetCanvas()

	cvs.cd(0)

	gr = ROOT.TGraphErrors(4096)

	gr.Draw("AP") # if you write "ALP" draw a line from the first to last and go back
	gr.SetMarkerStyle(21)

	gr.SetMarkerSize(0.4)
	gr.SetTitle("ADC Calibration ")

	t = 0.001
	
	self.Mon_Moux_Select(28)
	self.Connect_Keithley()

	self.Volt = []
	self.ADC_code = []
	
	#input number ('valori di voltagee')
	
	voltage_min = float(self.ADC_Calibration_Tension_Min.GetNumber())
	voltage_max = float(self.ADC_Calibration_Tension_Max.GetNumber())

	voltage_range = voltage_max - voltage_min

	number = int(self.ADC_Calibration_Points.GetNumber())
	
	g = voltage_range/number

        for x in range(number):
		
		time.sleep(0.1)
	
		voltage = voltage_min + g*x

		#print voltage

		self.Volt_Source_Keithley(voltage,0.5)


		a = []
		
		for u in range(4):

			self.send_message(MESSAGES.MESSAGE4)  # the sent message starts the ADC

			time.sleep(t)

        		self.received_message()

			self.send_message(MESSAGES.MESSAGE5)  # the sent message reads the ADC

        		time.sleep(t)

        		measurment = self.received_message()
	
			measurment = self.Read_HexToBin(measurment) # convert the HEX message in a list, each component of the list is a bit written as a string


			measurment = string.join(measurment)

        		measurment = ''.join(measurment.split())

			ADCValue = int(measurment, 2)  # convert the binary number in a decimal number 
			#print ADCValue
			a.append(ADCValue)

		mean = (a[0]+a[1]+a[2]+a[3])/4.0
		
		RMS = 0
			
		RMS = RMS +  (mean - a[0])*(mean-a[0])
		RMS = RMS +  (mean - a[1])*(mean-a[1])
		RMS = RMS +  (mean - a[2])*(mean-a[2])
		RMS = RMS +  (mean - a[3])*(mean-a[3])

		err = math.sqrt(RMS/3) # 3 = N - 1
		self.ADC_code.append(mean)
		
		gr.SetPoint(x+1,voltage,mean)
		gr.SetPointError(x+1,0,err)
	
		ROOT.gPad.Modified()
		ROOT.gPad.Update()

		if self.STOP == 1:
			break

	gr.GetXaxis().SetTitle("mV")

	gr.GetYaxis().SetTitle("ADC code" )


        ROOT.gPad.Modified()
	ROOT.gPad.Update()


	gr.Write()
	export_file.Close()

	self.Volt_Source_Keithley(0,0.5) 
	print "ciao"

def ADC_Code_Density_Ex(self):
	
	data = datetime.datetime.now()
		
	my_time_minute = str(data.minute)
	my_time_hour = str(data.hour)
	my_day = str(data.day)
	my_month = str(data.month)
	my_year = str(data.year)
	

	filename = ["ADC_Code_Density"]
	filename.append(my_time_hour)
	filename.append(my_time_minute)
	filename.append(my_day)
	filename.append(my_month)
	filename.append(my_year)
 	filename.insert(0,"CHIPIX_response_board/")
	filename.append('.root')
	filename = string.join(filename)
	filename = filename.replace(" ","_")
	filename = filename.replace("2017_.root","2017.root")

	export_file = ROOT.TFile(filename,"RECREATE")	
	self.STOP = 0

	cvs = self.Canvas_ADC_Code_Density.GetCanvas()

	cvs.cd(0)

	gr2 = ROOT.TH1F("ADC_Code_Density", "ADC Code Density", 4096 , 0, 4095)

	gr2.GetXaxis().SetTitle(" ADC Code ")

	gr2.GetYaxis().SetTitle("  " )

	histo_range_start = int((4096/900.0)*float(self.ADC_Code_Density_Calibration_Tension_Min.GetNumber()))
	histo_range = 50 

	gr2.SetAxisRange(histo_range_start ,histo_range,"X")
	gr2.SetAxisRange(0,60,"Y")
	

	#gr2.SetMaximum(20)
	
	gr2.Draw() 
	
	t = 0.001
	
	self.Mon_Moux_Select(28)
	self.Connect_Keithley()

	
	#voltage_min = float(self.ADC_Calibration_Tension_Min.GetNumber())
	#voltage_max = float(self.ADC_Calibration_Tension_Max.GetNumber())

	#voltage_range = voltage_max - voltage_min

	step  = int(self.ADC_Code_Density_Tension_Step.GetNumber())
	
	number = int(900.0/(step/1000.0))	
	
	#start = time.time()
        #print start

	for x in range(number):
		
		voltage = x*(step/1000.0)+ float(self.ADC_Code_Density_Calibration_Tension_Min.GetNumber())

		print voltage

		#print voltage
		if voltage < 200.0: 
	
			time.sleep(0.3)
			self.Volt_Source_Keithley(voltage,0.1)

		else: 
			time.sleep(0.1)
			self.Volt_Source_Keithley(voltage,0.5)
				

	
		if voltage > self.ADC_Code_Density_Calibration_Tension_Max.GetNumber():
	
			break

		time.sleep(t)

		self.send_message(MESSAGES.MESSAGE4)  # the sent message starts the ADC
		time.sleep(t)

       		self.received_message()
		time.sleep(t)

		self.send_message(MESSAGES.MESSAGE5)  # the sent message reads the ADC
        	time.sleep(t)

        	measurment = self.received_message()
		measurment = self.Read_HexToBin(measurment) # convert the HEX message in a list, each component of the list is a bit written as a string
		measurment = string.join(measurment)
        	measurment = ''.join(measurment.split())

		ADCValue = int(measurment, 2)  # convert the binary number in a decimal number 
		
		if ADCValue > histo_range:
	
			histo_range = histo_range + 50

			gr2.SetAxisRange(histo_range - 50 ,histo_range,"X")   
			
		#gr2.SetAxisRange ( 0 , Double_t xmax, "X")
		
		gr2.Fill(ADCValue)

		ROOT.gPad.Modified()
		ROOT.gPad.Update()

		if self.STOP == 1:
			break

	gr2.Write()
	export_file.Close()

	self.Volt_Source_Keithley(0,0.5)  

	print "ciao"
