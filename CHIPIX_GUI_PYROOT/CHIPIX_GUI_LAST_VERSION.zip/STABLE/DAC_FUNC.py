import ROOT
import MESSAGES
import string
import time
import os
import datetime
from os.path import exists
import math

def Calibrate_DAC_Ex(self): 

	self.STOP = 0
	DAC_numb  =  self.CalLevel_ComboBox.GetSelected()
	#print DAC_numb

	t = 0.00005

# 1 --> CALL Level [201:192]
# 2 -->	ICTRL	   [36:27]			
# 3 --> VTH	   [46:37]	
# 4 --> VBL	   [56:47]	
# 5 --> BIASP1	   [66:57]
# 6 --> BIASP2     [76:67]
# 7 --> DISC       [86:77]
# 8 --> BIAS SF    [96:87]
# 9 --> KRUM	   [106:97]
# 10 -> FEED       [116:107]
 
	
	#### create a file where saving the DAC data ###

	try:
		os.stat("CHIPIX_response_board")
	except:
		os.mkdir("CHIPIX_response_board")  

	data = datetime.datetime.now()
	
	my_time_minute = str(data.minute)
	my_time_hour = str(data.hour)
	my_day = str(data.day)
	my_month = str(data.month)
	my_year = str(data.year)
	
	if DAC_numb == 1:
		filename  = ["CAL_LEVEL_DAC"]
	elif DAC_numb == 2:
		filename = ["ICTRL"]
	elif DAC_numb == 3:
		filename = ["VTH"]
	elif DAC_numb == 4:
		filename = ["VBL"]
	elif DAC_numb == 5:
		filename = ["BIASP1"]
	elif DAC_numb == 6:
		filename = ["BIASP2"]
	elif DAC_numb == 7:
		filename = ["DISC"]
	elif DAC_numb == 8:
		filename = ["BIAS_SF"]
	elif DAC_numb == 9:
		filename = ["VRef_KRUM"]
	elif DAC_numb == 10:
		filename = ["BIAS_FEED"]



###################################################################################################
# create a file
###################################################################################################
	filename.append(my_time_hour)
	filename.append(my_time_minute)
	filename.append(my_day)
	filename.append(my_month)
	filename.append(my_year)
 	filename.insert(0,"CHIPIX_response_board/")
	filename.append('.root')
	filename = string.join(filename)
	filename = filename.replace(" ","_")
	self.filename = filename.replace("2017_.root","2017.root")
		

	"""
###################################################################################################
# create a directory
#####################################################################################################


	cost_path = ["CHIPIX_response_board"]
	cost_path.append(filecreator)
	cost_path = string.join(cost_path)
	path = cost_path.replace(" ","/")


####################################################################################################
# file exist?
####################################################################################################

	if(exists(path)):
		f = open(path,"a")
		f.write("\n ")

	else:
		f = open(path,"w")
		f.write("\n ")

	f.write("# DAC Counter		Voltage[mV]")
	f.write("\n ")
	f.closed
	"""
	global export_file1
	export_file1 = ROOT.TFile(self.filename,"RECREATE")

#d.Write()
#w.Write()
	####### canvas part #####

	cvs = self.Canvas_CalLevel.GetCanvas()

	cvs.cd(0)

	self.gr = ROOT.TGraphErrors(1024)

	self.gr.Draw("AP") # if you write "ALP" draw a line from the first to last and go back

	self.gr.SetMarkerStyle(21)

	self.gr.SetMarkerSize(0.4)

	self.gr.GetXaxis().SetTitle("DAC Code")

	self.gr.GetYaxis().SetTitle(" mV " )

	self.gr.SetTitle("DAC Calibration ")
	
	#print ( cvs.GetListOfPrimitives().At(0).GetName())
	#print type( cvs.GetListOfPrimitives().At(0))

#### Change the Multiplex --> write Mon Moux ###

# 1 --> CALL Level [201:192]
# 2 -->	ICTRL	   [36:27]			
# 3 --> VTH	   [46:37]	
# 4 --> VBL	   [56:47]	
# 5 --> BIASP1	   [66:57]
# 6 --> BIASP2     [76:67]
# 7 --> DISC       [86:77]
# 8 --> BIAS SF    [96:87]
# 9 --> KRUM	   [106:97]
# 10 -> FEED       [116:107]
 
	self.Mon_Moux_list = [7,2,21,4,5,17,18,19,20,6,21]
	self.Mon_Moux_Select(self.Mon_Moux_list[DAC_numb])


	self.y_err= []
	self.y = []
	self.DAC_code = []
	self.Connect_Keithley()
	self.Volt_Measurment_Keithley()

	for x in range(1024):
		
	        
		self.Write_DAC_Code(DAC_numb,x)
		

		### it makes the measurement 4 times than does a mean 
		a  = range(4)
	
		#1
		measurement = self.Read_Keithley()      
		a[0] = measurement
		#2
		"""
		measurement = self.Read_Keithley()       
		a[1] = measurement        
		#3
		measurement = self.Read_Keithley()       
		a[2] = measurement        
		#4
		measurement = self.Read_Keithley()       
		a[3] = measurement        
		
		mean = (a[0]+a[1]+a[2]+a[3])/4
 		
		
		RMS = 0
			
		RMS = RMS +  (mean - a[0])*(mean-a[0])
		RMS = RMS +  (mean - a[1])*(mean-a[1])
		RMS = RMS +  (mean - a[2])*(mean-a[2])
		RMS = RMS +  (mean - a[3])*(mean-a[3])

		err = math.sqrt(RMS/3) # 3 = N - 1
		
		
	
		#err = (max(a[0],a[1],a[2],a[3])-min(a[0],a[1],a[2],a[3]))/2
		#print err 
	
		
		"""
		mean = measurement
		err = 0.1	
		self.y.append(mean)
		self.y_err.append(err)
		self.DAC_code.append(x)

		x1 = float(x)			
		y1 = mean

		self.gr.SetPoint(x+1, x1, y1)
		self.gr.SetPointError(x+1,0,err)

		self.gr.GetYaxis().SetTitle("mV")

		self.gr.GetXaxis().SetTitle("DAC code" )


		ROOT.gPad.Modified()
		ROOT.gPad.Update()

		data = [ str(x1),"\t\t",str(y1),"\t",str(err)]
		
		data = string.join(data)
		#:print data

		"""
		f.write(data)
		f.write('\n')
		f.closed
		
		"""
		if self.STOP == 1: 
			return 0


        ROOT.gPad.Modified()
	ROOT.gPad.Update()


	self.gr.Write("Calibration")
	export_file.Close()

def FIT_Ex(self):
		

		cvs1 = self.Canvas_CalLevel.GetCanvas()

		cvs1.cd(0)
		"""
		self.gr.Fit("pol1","RV","",1, int(len(self.y_CAL_LEVEL))+1)

		f2 = ROOT.TF1("f2", self.gr.Fit, 1,  int(len(self.y_CAL_LEVEL))+1, 2)
		"""
		self.gr.Fit("pol1","RV","",int(self.CalLevel_FitRange_Min.GetNumber()), int(self.CalLevel_FitRange_Max.GetNumber()))

		f2 = ROOT.TF1("f2", self.gr.Fit,int(self.CalLevel_FitRange_Min.GetNumber()), int(self.CalLevel_FitRange_Max.GetNumber()), 2)

		f2.SetParNames("a","b");		

		f2.SetNpx(10000)

		f2.SetLineStyle(1)

		f2.SetLineColor(1)

		f2.SetLineWidth(1)

		ROOT.gStyle.SetOptFit()

		f2.Draw

		ROOT.gPad.Modified()

		ROOT.gPad.Update()






def CalLevel_Dispersion_Ex(self):
	

	self.STOP = 0


	t = 0.00005

	DAC_numb  =  self.CalLevel_ComboBox.GetSelected()      


	#### Change the Multiplex --> write on Mon Mux###
	self.Mon_Moux_list = [7,2,21,4,5,17,18,19,20,6,21]     
	self.Mon_Moux_Select(self.Mon_Moux_list[DAC_numb])
	

	self.Write_DAC_Code(DAC_numb,int(self.CalLevel_Dispersion_Code.GetNumber()))

	cvs2 = self.Canvas_CalLevel.GetCanvas()

	cvs2.cd(0)

	measurement = self.Read_Keithley()
   
	self.gr2 = ROOT.TH1F("CAL_LEVEL_dispersion", "Measurements Dispersion",50, measurement-1, measurement+1)

	self.gr2.GetXaxis().SetTitle(" mV ")

	self.gr2.GetYaxis().SetTitle("  " )

	self.gr2.Draw() 


	for x in range(int(self.CalLevel_Dispersion_Measurements.GetNumber())):

	
	
		measurement = self.Read_Keithley()       
 		#print measurement 
		self.n_dispersion = []
		self.n_dispersion.append(measurement)

		self.gr2.Fill(measurement)
		#self.gr2.AddBinContent(1,measurement)
		#self.gr2.Write()
		ROOT.gPad.Modified()
		ROOT.gPad.Update()
		
		if self.STOP == 1: 
			return 0

	self.gr2.Fit("gaus")
	
	gaus = self.gr2.GetFunction('gaus')
	

	mean  = gaus.GetParameter(1)
	#print mean

	mean_err = gaus.GetParError(1)
	#print mean_err
	
	mean_parameters = [mean,mean_err]

	ROOT.gStyle.SetOptFit()     


	self.gr2.Write("Measurements_dispersion")
	export_file1.Close()
	
	print mean_parameters
	return mean_parameters



def DAC_Code_Dispersion_Ex(self,DAC_code):
	
	#self.filename_dispersion = filename.replace("2017.root","2017_Dispersion.root") 
	#export_file =ROOT.TFile(self.filename,"RECREATE")
	
	self.STOP = 0


	t = 0.00005

	DAC_numb  =  self.CalLevel_ComboBox.GetSelected()      

	self.CalLevel_Dispersion_Code.SetNumber(DAC_code)

	self.Write_DAC_Code(DAC_numb,int(DAC_code))

	cvs2 = self.Canvas_CalLevel.GetCanvas()

	cvs2.cd(0)

	measurement = self.Read_Keithley()
   
	gr2 = ROOT.TH1F("CAL_LEVEL_dispersion", "Measurements Dispersion",40, measurement-1, measurement+1)

	gr2.GetXaxis().SetTitle(" mV ")

	gr2.GetYaxis().SetTitle("  " )

	gr2.Draw() 
	
	"""
	data = datetime.datetime.now()
	title = ["2017_",str(data.second),"_GAUS_Calibration.png"]
	title = string.join(title)
	title = ''.join(title.split())
	"""		
	
	#for x in range(int(self.DAC_Gaus_Calibration_Measurements).GetNumber())):
	for x in range(int(self.DAC_Gaus_Calibration_Measurements.GetNumber())):
		
		measurement = self.Read_Keithley()       
		gr2.Fill(measurement)
		ROOT.gPad.Modified()
		ROOT.gPad.Update()
	
		self.CalLevel_Dispersion_Measurements.SetNumber(x)	

	gr2.Fit("gaus")
	gaus = gr2.GetFunction('gaus')
	mean  = gaus.GetParameter(1)
	#print mean
	mean_err = gaus.GetParameter(2)
	#print mean_err
	mean_parameters = [mean,mean_err]

	ROOT.gStyle.SetOptFit()     


	
	gr2.Write("Measurements_dispersion")
	#export_file.Close()
	
	print mean_parameters
	return mean_parameters


def DAC_Gaus_Calibration_Ex(self): 

	self.STOP = 0
	DAC_numb  =  self.CalLevel_ComboBox.GetSelected()
#	print DAC_numb

	t = 0.00005

# 1 --> CALL Level [201:192]
# 2 -->	ICTRL	   [36:27]			
# 3 --> VTH	   [46:37]	
# 4 --> VBL	   [56:47]	
# 5 --> BIASP1	   [66:57]
# 6 --> BIASP2     [76:67]
# 7 --> DISC       [86:77]
# 8 --> BIAS SF    [96:87]
# 9 --> KRUM	   [106:97]
# 10 -> FEED       [116:107]
 
	
	#### create a file where saving the DAC data ###

	try:
		os.stat("CHIPIX_response_board")
	except:
		os.mkdir("CHIPIX_response_board")  

	data = datetime.datetime.now()
	
	my_time_minute = str(data.minute)
	my_time_hour = str(data.hour)
	my_day = str(data.day)
	my_month = str(data.month)
	my_year = str(data.year)
	
	if DAC_numb == 1:
		filename  = ["CAL_LEVEL_DAC"]
	elif DAC_numb == 2:
		filename = ["ICTRL"]
	elif DAC_numb == 3:
		filename = ["VTH"]
	elif DAC_numb == 4:
		filename = ["VBL"]
	elif DAC_numb == 5:
		filename = ["BIASP1"]
	elif DAC_numb == 6:
		filename = ["BIASP2"]
	elif DAC_numb == 7:
		filename = ["DISC"]
	elif DAC_numb == 8:
		filename = ["BIAS_SF"]
	elif DAC_numb == 9:
		filename = ["VRef_KRUM"]
	elif DAC_numb == 10:
		filename = ["BIAS_FEED"]



###################################################################################################
# create a file
###################################################################################################
	filename.append(my_time_hour)
	filename.append(my_time_minute)
	filename.append(my_day)
	filename.append(my_month)
	filename.append(my_year)
 	filename.insert(0,"CHIPIX_response_board/")
	filename.append('.root')
	filename = string.join(filename)
	filename = filename.replace(" ","_")
	self.filename = filename.replace("2017_.root","2017_GAUS_Calibration.root")
		


	global export_file
	export_file  =ROOT.TFile(self.filename,"RECREATE")


#d.Write()
#w.Write()
	####### canvas part #####

	cvs = self.Canvas_CalLevel.GetCanvas()

	cvs.cd(0)

	self.gr = ROOT.TGraphErrors(1024)

	#print ( cvs.GetListOfPrimitives().At(0).GetName())
	#print type( cvs.GetListOfPrimitives().At(0))

#### Change the Multiplex --> write Mon Moux ###

# 1 --> CALL Level [201:192]
# 2 -->	ICTRL	   [36:27]			
# 3 --> VTH	   [46:37]	
# 4 --> VBL	   [56:47]	
# 5 --> BIASP1	   [66:57]
# 6 --> BIASP2     [76:67]
# 7 --> DISC       [86:77]
# 8 --> BIAS SF    [96:87]
# 9 --> KRUM	   [106:97]
# 10 -> FEED       [116:107]
 
	self.Mon_Moux_list = [7,2,21,4,5,17,18,19,20,6,21]
	self.Mon_Moux_Select(self.Mon_Moux_list[DAC_numb])


	self.y_err= []
	self.y = []
	self.DAC_code = []

	self.Connect_Keithley()
	self.Volt_Measurment_Keithley()

	number = int(self.DAC_Gaus_Calibration_Points.GetNumber())
	
	for x in range(number+1):

		a = 1023/number

		mean_parameters = self.DAC_Code_Dispersion(x*a)

		mean = mean_parameters[0]
		err = mean_parameters[1]
		print mean
		self.y.append(mean)
		self.y_err.append(err)
		self.DAC_code.append(x*a)
		#print self.y_CALL_LEVEL

		x1 = float(x*a)			
		y1 = mean

		self.gr.SetPoint(x+1, x1, y1)
		self.gr.SetPointError(x+1,0,err)

		if self.STOP == 1: 
			return 0

	self.LSB = self.y[len(self.y) - 1 ] 

	self.gr.Draw("AP") # if you write "ALP" draw a line from the first to last and go back

	self.gr.SetMarkerStyle(21)

	self.gr.SetMarkerSize(0.4)

	self.gr.GetXaxis().SetTitle("DAC Code")

	self.gr.GetYaxis().SetTitle(" mV " )

	self.gr.SetTitle("DAC Calibration ")

	cvs.cd(0)

	ROOT.gPad.Modified()
	ROOT.gPad.Update()

		
	self.gr.Write("Calibration")
	export_file.Close()

	for x in range (number + 1):
		print str(self.y[x]) + '\t' + str(self.y_err[x])





def Mon_Moux_Select_Ex(self,number):

	t = 0.00005

	number_bin = self.Write_DecToBin(number,5)
	
	number_GCR_7 = number_bin[4]
	
	number_GCR_8 = range(4)

	for y in range(4):
		
		number_GCR_8[y] = number_bin[y]
	
	number_GCR_8 = string.join(number_GCR_8)
	number_GCR_8 = ''.join(number_GCR_8)
	
	
	#### write on GCR 7 ###
	
	self.send_message(MESSAGES.MESSAGES_GCR_NM[7]) # the message sent point to the GCR 7
	time.sleep(t)
	self.received_message()
	
	self.send_message(MESSAGES.MESSAGE_READ_GCR) # reads the bit of the GCR 7
	time.sleep(t)
	GCR_Original = self.received_message()
	GCR_Original = self.Read_HexToBin(GCR_Original)

	UnwrittenBits = range(15)

	for x in range (15):
		
		UnwrittenBits[x] = GCR_Original[x+1]
	
	UnwrittenBits = string.join(UnwrittenBits)
	UnwrittenBits = ''.join(UnwrittenBits.split())
	
	GCR7_new = ['0001',number_GCR_7, UnwrittenBits]
	GCR7_new = string.join(GCR7_new)
	GCR7_new = ''.join(GCR7_new.split())
	#print GCR7_new
	GCR7_new = self.Bin_to_Message(GCR7_new)
	
	time.sleep(t)
	self.send_message(GCR7_new)
	time.sleep(t)
	self.received_message()
 
	

	#### write on GCR 8 ### 

	self.send_message(MESSAGES.MESSAGES_GCR_NM[8]) # the message sent point to the GCR 8
	time.sleep(t)
	self.received_message()
	
	self.send_message(MESSAGES.MESSAGE_READ_GCR) # reads the bit of the GCR 8
	time.sleep(t)
	GCR_Original = self.received_message()
	GCR_Original = self.Read_HexToBin(GCR_Original)

	UnwrittenBits = range(12)

	for x in range (12):
		
		UnwrittenBits[x] = GCR_Original[x]
	
	UnwrittenBits = string.join(UnwrittenBits)
	UnwrittenBits = ''.join(UnwrittenBits.split())
	
	GCR8_new = ['0001',UnwrittenBits,number_GCR_8]
	GCR8_new = string.join(GCR8_new)
	GCR8_new = ''.join(GCR8_new.split())
	#print GCR8_new
	GCR8_new = self.Bin_to_Message(GCR8_new)
	
	time.sleep(t)
	self.send_message(GCR8_new)
	time.sleep(t)
	self.received_message()



def Write_DAC_Code_Ex(self,DAC_numb,DAC_code):

# The number and the bits on GCR of the DAC are: ###
# 
#
# 1 --> CALL Level [201:192]
# 2 -->	ICTRL	   [36:27]			
# 3 --> VTH	   [46:37]	
# 4 --> VBL	   [56:47]	
# 5 --> BIASP1	   [66:57]
# 6 --> BIASP2     [76:67]
# 7 --> DISC       [86:77]
# 8 --> BIAS SF    [96:87]
# 9 --> KRUM	   [106:97]
# 10 -> FEED       [116:107]
 
	first_bit_DAC_on_GCR = [0,192,27,37,47,57,67,77,87,97,107]
	
	last_bit_DAC_on_GCR = [0,201,36,46,56,66,76,86,96,106,116]


	DAC_code_list= self.Write_DecToBin(DAC_code,10)
		
	#print DAC_code_list
	
	#DAC_code = string.join(VTh_bits)	
	#VTh_bits = ''.join(VTh_bits.split())	
	

	### read the actual state of GCRS ###
	
	t = 0.00005

	self.send_message(MESSAGES.MESSAGE1) # the message points the GCR address in automode
 	time.sleep(t)
	self.received_message()
	time.sleep(t)


	### GCR DATA ### it's a list of 224 bits written as string 

	GCR_DATA = []

	i = 0

	while i < 14 :
	
		self.send_message(MESSAGES.MESSAGE2) # the message sent read the 16 bits of payload on the GCR 
		time.sleep(t)
	
		GCR_X_received_hex = self.received_message() # gives the hex message recived from FPGA
		GCR_X_received_bin = self.Read_HexToBin( GCR_X_received_hex )
		#print GCR_X_received_bin 

		a = 0

		while a < 16 :
			
			GCR_DATA.insert(0,GCR_X_received_bin[15-a]) 
			a = a + 1
		
		i = i + 1
	"""
	for w in range(14):
	
		m = range(16)
		for u in range(16):

			m[15-u] = GCR_DATA[223-16*w-u]
		print m
	print "\n"
	"""

	#print GCR_DATA

	#Unwritten_GCR_before = range(first_bit_DAC_on_GCR[DAC_numb]-1)
	#print Unwirtten_GCR_before
	
	#Unwritten_GCR_after  = range(224-last_bit_DAC_on_GCR[DAC_numb])
	#print Unwirtten_GCR_after
	
	for x in range(224):

		if x < 223 - last_bit_DAC_on_GCR[DAC_numb]:
		
			GCR_DATA[x] = GCR_DATA[x]
			#GCR_DATA[x] = '0'

		elif x <= 223 - first_bit_DAC_on_GCR[DAC_numb]:

			GCR_DATA[x] =  DAC_code_list[abs(223-last_bit_DAC_on_GCR[DAC_numb]-x)]
			#GCR_DATA[x] = '1'
		

		elif x >  223 - first_bit_DAC_on_GCR[DAC_numb]:

			GCR_DATA[x] = GCR_DATA[x]
			#GCR_DATA[x] = '0'
	"""		
	print "\n"
	for w in range(14):
	
		m = range(16)
		for u in range(16):

			m[15-u] = GCR_DATA[223-16*w-u]
		print m
	"""
	i = 0

	while i < 14:
		
		self.send_message(MESSAGES.MESSAGES_GCR_NM[i])
		time.sleep(t)
		self.received_message()
	
		b  = 0
	
		GCR_X_DATA = range(16)

		while b < 16 :

			GCR_X_DATA[15 - b] = GCR_DATA[223-16*i-b]

			b = b + 1

		#print GCR_X_DATA

		GCR_X_DATA.insert(0,'0001') # insert the SPI COMMAND: write on GCR

		#print GCR_X_DATA
	
        	GCR_X_DATA = string.join(GCR_X_DATA)

        	GCR_X_DATA = ''.join(GCR_X_DATA.split())

		#print GCR_X_DATA

		MESSAGE_OUT = self.Bin_to_Message(GCR_X_DATA)
		
		#print MESSAGE_OUT

		time.sleep(t)
		self.send_message(MESSAGE_OUT)

		time.sleep(t)
        	self.received_message()
		
		i = i + 1
	
	#print len(GCR_DATA)
	#r = range(10)

	#for s in range(10):

		#r[s] = GCR_DATA[first_bit_DAC_on_GCR[DAC_numb]+s]
	#print r



def DNL_Ex(self):

	ideal_LSB_step_width = self.LSB/1023
	#print ideal_LSB_step_width
	
	self.gr.Fit("pol1","RV","",int(self.DNL_FitRange_Min.GetNumber()), int(self.DNL_FitRange_Max.GetNumber()))

	f2 = ROOT.TF1("f2", self.gr.Fit,int(self.DNL_FitRange_Min.GetNumber()), int(self.DNL_FitRange_Max.GetNumber()), 2)

	#f2.SetParNames("a","b");		

	f2.SetNpx(10000)
	
	fit = self.gr.GetFunction('pol1')     
	a = fit.GetParameter(0)
	b = fit.GetParameter(1)

	DNL = []
	
	cvs3 = self.Canvas_DNL.GetCanvas()

	cvs3.cd(0)

	gr2 = ROOT.TGraph(1024)
	
	i = 0

	while i < int(len(self.DAC_code)):
		
		if self.DAC_code[i] < int(self.DNL_FitRange_Min.GetNumber()):
	
			i = i + 1 

		elif self.DAC_code[i] <=  int(self.DNL_FitRange_Max.GetNumber()):

			y = a + self.DAC_code[i]*b

			result = (y - self.y[i])/ideal_LSB_step_width #/(self.y[i])
			DNL.append(result)		
		
			gr2.SetPoint(i+1,self.DAC_code[i],result)

			i = i + 1

		elif self.DAC_code[i] >  int(self.DNL_FitRange_Max.GetNumber()):

			break 

	

	gr2.Draw("AP") # if you write "ALP" draw a line from the first to last and go back

	gr2.SetMarkerStyle(21)

	gr2.SetMarkerSize(0.4)

	gr2.GetXaxis().SetTitle("DAC Code")

	gr2.GetYaxis().SetTitle(" DNL " )

	gr2.SetTitle(" DNL  ")


	ROOT.gPad.Modified()
	ROOT.gPad.Update()

	export_file.Open(self.filename)
	gr2.Write()
	export_file.Close()

def Mux_Ex(self):

	entry = int( self.DAC_Mux.GetNumber())

	if entry == 0:

		message = MESSAGES.MESSAGE_enable_mux_0
		
	elif entry == 1: 

		message = MESSAGES.MESSAGE_enable_mux_1
		
	elif entry == 2:

		message = MESSAGES.MESSAGE_enable_mux_2
		
	elif entry == 3:

		message = MESSAGES.MESSAGE_enable_mux_3

	self.send_message(message)
	time.sleep(0.0005)
	received = self.received_message()

 	received = self.Read_HexToBin(received)
	print received
	print "ciao"	



def STOP_Button_Ex(self):

	self.STOP = 1
