	
import ROOT

def Keithley_Graph_Ex(self):
	
	self.KeithleyFrame1 = ROOT.TGHorizontalFrame (self.tab6 )

	self.KeithleyConnectButton = ROOT.TGTextButton( self.KeithleyFrame1 ,"  Connect KEITHLEY  ")
	
	self.KeithleyConnectLabel = ROOT.TGLabel (self.KeithleyFrame1,"                                       " ) 

	self.Do_Connect_Keithley = ROOT.TPyDispatcher( self.Connect_TAB_Keithley) # this command translate the python command in C++ launguage I think
	self.KeithleyConnectButton.Connect('Clicked()' , 'TPyDispatcher' , self.Do_Connect_Keithley,'Dispatch()')
	
	self.KeithleyFrame1.AddFrame(self.KeithleyConnectButton, ROOT.TGLayoutHints(ROOT.kLHintsTop|ROOT.kLHintsLeft,10,10,0,10))

	self.KeithleyFrame1.AddFrame(self.KeithleyConnectLabel, ROOT.TGLayoutHints(ROOT.kLHintsTop|ROOT.kLHintsLeft ,50,10,5,10))
	self.tab6.AddFrame(self.KeithleyFrame1, ROOT.TGLayoutHints(ROOT.kLHintsTop|ROOT.kLHintsLeft, 10,10,10,10))
	
