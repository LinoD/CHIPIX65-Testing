import serial
import sys
import time
import string

def Connect_TAB_Keithley_Ex():

	if(len(sys.argv) == 2) :
		portName = sys.argv[1]
	else:
		portName = "/dev/ttyUSB0"

	s =  serial.Serial()
	
	try:
		s.open() 
                cmd = '*RST'
                s.write( cmd + '\r\n' )
        	KeithleyConnectButton.SetTextColor(250)
                print 'Keithley connected'
        except:
                print 'Failed to conncect Keithley'
		for x in range(5):
	
			KeithleyConnectLabel.SetText( "Check the USB connection" )
			time.sleep(0.8)
			KeithleyConnectLabel.SetText( "   " )
			time.sleep(0.8)
		
		KeithleyConnectLabel.SetText( "   " )

def Connect_Keithley_Ex():

	if(len(sys.argv) == 2) :
		portName = sys.argv[1]
	else:
		portName = "/dev/ttyUSB0"
	
	global  s
	s = serial.Serial()
	

	s.port      = portName                 # target port for connection
	s.baudrate  = 9600                     # Baud rate
	s.bytesize  = serial.EIGHTBITS         # number of payload bits.per byte
	s.parity    = serial.PARITY_NONE       # enable/dis.ble parity check
	s.stopbits  = serial.STOPBITS_ONE      # number of s.op bits
	s.timeout   = None                     # timeout in s.conds
	s.xonoff    = False                    # enable/dis.ble s.ftware flow control
	s.rtscts    = False                    # enable/dis.ble RTS/CTS hardware flow control
	s.dsrdtr    = False                    # enable/dis.ble DSR/DTR hardware flow control 
	
	try:
		s.close() 
        except:
                print ''
	
	try:
		s.open() 
                print 'Keithley connected'
        except:
                print 'Failed to conncect Keithley'
	
def Volt_Measurment_Keithley_Ex():


	cmd = ':SOUR:FUNC CURR'

	s.write( cmd + '\r\n' )

	cmd = ':SOUR:CURR:MODE FIXED'

	s.write( cmd + '\r\n' )

	cmd = ':SENS:FUNC "VOLT"'

	s.write (cmd + '\r\n' )

	cmd = ':SOUR:CURR:RANG MIN'

	s.write( cmd + '\r\n' )

	cmd = ':SOUR:CURR:LEV 0'

	s.write( cmd + '\r\n' )

	cmd = ':SENS:VOLT:PROT 2'

	s.write( cmd + '\r\n' )

	cmd = ':SENS:VOLT:RANGE 2'

	s.write( cmd + '\r\n' )

	cmd = ':FORM:ELEM VOLT'

	s.write( cmd + '\r\n' )

	cmd = ':OUTP ON'

	s.write( cmd + '\r\n' )


def Volt_Source_Keithley_Ex(value, sens):
	"""
	:SOUR:FUNC VOLT
	:SOUR:VOLT:MODE FIXED
	Set source range, level, compliance :SOUR:VOLT:RANG 20
	:SOUR:VOLT:LEV 10
	:SENS:CURR:PROT 10E-3
	Set measure function, range
	:SENS:FUNC "CURR"
	:SENS:CURR:RANG 10E-3
	:FORM:ELEM CURR
	Turn on output
	:OUTP ON
	Read data
	:READ?
	:OUTP OFF
	
	"""
	#cmd = '*RST'

	#s.write( cmd + '\r\n' )
	value = float(value)
	value = value/1000
	value = str(value)
	
	value_command = [':SOUR:VOLT:LEV',value]
	value_command = string.join(value_command)
	print value_command

	cmd = ':SENS:CURR:PROT 5E-4'

	s.write (cmd + '\r\n' )


	cmd = ':SENS:VOLT:PROT 1.2'

	s.write (cmd + '\r\n' )

	cmd = ':SOUR:FUNC VOLT'

	s.write( cmd + '\r\n' )

	cmd = ':SOUR:VOLT:MODE FIXED'
  
	s.write( cmd + '\r\n' )  
	
	sens = float(sens)
	sens = str(sens)
	
	sens_command = [':SOUR:VOLT:RANG',sens]
	sens_command = string.join(sens_command)
	
	cmd = sens_command
	
	s.write( cmd + '\r\n' ) 
	

	#cmd = ':SOUR:VOLT:LEV 0.023'

	cmd = value_command
	
	s.write( cmd + '\r\n' )
	
		#cmd = ':SOUR:CURR:RANG MIN'

	#s.write( cmd + '\r\n' )

	#cmd = ':SENS:VOLT:PROT 2'

	#s.write( cmd + '\r\n' )

	#cmd = ':SENS:VOLT:RANGE 2'

	#s.write( cmd + '\r\n' )

	#cmd = ':FORM:ELEM VOLT'

	#s.write( cmd + '\r\n' )

	cmd = ':OUTP ON'

	s.write( cmd + '\r\n' )


def Read_Keithley_Ex():

		
	cmd = ':READ?'

	s.write( cmd + '\r\n' )
	

	measurement = s.read(14)
	#print measurement 

	measurement = measurement.replace('E','e',1)
	"""
	measurement = measurement.replace("e+00","",1)
	measurement = measurement.replace("e-01","",1)
	measurement = measurement.replace("e-02","",1)
	measurement = measurement.replace("+", "",1) 
	print measurement
			#print type(measurement)
	"""
	measurement = float(measurement)
	"""	
	if measurement < 2.0:
				numb_of_zero = 1000.0
	else:	
				numb_of_zero = 100.0 
	"""
	measurement = measurement*1000      
	
	return measurement


Connect_Keithley_Ex()
#Volt_Measurment_Keithley_Ex()
#Read_Keithley_Ex()

i = 0

while i < 4:
	#delay = input("time sleep" + "\n")
 		delay = 0.01
	#for t in range(3):

		for x in range(10):
	
	#voltage = input ("write voltage in mV")
			time.sleep(delay)
			Volt_Source_Keithley_Ex(x*100, 0.5)
	
		for x in range(10):
	
	#voltage = input ("write voltage in mV")
			time.sleep(delay)
			Volt_Source_Keithley_Ex(1000-x*100,0.5)
	#time.sleep(0.1)
	#Volt_Source_Keithley_Ex(200,0.5)  
