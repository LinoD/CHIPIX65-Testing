import serial
import sys
import time
import string

def Connect_TAB_Keithley_Ex(self):

	if(len(sys.argv) == 2) :
		portName = sys.argv[1]
	else:
		portName = "/dev/ttyUSB0"

	self.s =  serial.Serial()
	
	try:
		self.s.open() 
                cmd = '*RST'
                self.s.write( cmd + '\r\n' )
        	self.KeithleyConnectButton.SetTextColor(250)
                print 'Keithley connected'
        except:
                print 'Failed to conncect Keithley'
		for x in range(5):
	
			self.KeithleyConnectLabel.SetText( "Check the USB connection" )
			time.sleep(0.8)
			self.KeithleyConnectLabel.SetText( "   " )
			time.sleep(0.8)
		
		self.KeithleyConnectLabel.SetText( "   " )

def Connect_Keithley_Ex(self):

	if(len(sys.argv) == 2) :
		portName = sys.argv[1]
	else:
		portName = "/dev/ttyUSB0"

	self.s = serial.Serial()
	

	self.s.port      = portName                 # target port for connection
	self.s.baudrate  = 9600                     # Baud rate
	self.s.bytesize  = serial.EIGHTBITS         # number of payload bitself.s.per byte
	self.s.parity    = serial.PARITY_NONE       # enable/diself.s.ble parity check
	self.s.stopbits  = serial.STOPBITS_ONE      # number of self.s.op bits
	self.s.timeout   = None                     # timeout in self.s.conds
	self.s.xonoff    = False                    # enable/diself.s.ble self.s.ftware flow control
	self.s.rtscts    = False                    # enable/diself.s.ble RTS/CTS hardware flow control
	self.s.dsrdtr    = False                    # enable/diself.s.ble DSR/DTR hardware flow control 
	
	try:
		self.s.close() 
        except:
                print ''
	
	try:
		self.s.open() 
                print 'Keithley connected'
        except:
                print 'Failed to conncect Keithley'
	
def Volt_Measurment_Keithley_Ex(self):


	cmd = ':SOUR:FUNC CURR'

	self.s.write( cmd + '\r\n' )

	cmd = ':SOUR:CURR:MODE FIXED'

	self.s.write( cmd + '\r\n' )

	cmd = ':SENS:FUNC "VOLT"'

	self.s.write (cmd + '\r\n' )

	cmd = ':SOUR:CURR:RANG MIN'

	self.s.write( cmd + '\r\n' )

	cmd = ':SOUR:CURR:LEV 0'

	self.s.write( cmd + '\r\n' )

	cmd = ':SENS:VOLT:PROT 2'

	self.s.write( cmd + '\r\n' )

	cmd = ':SENS:VOLT:RANGE 2'

	self.s.write( cmd + '\r\n' )

	cmd = ':FORM:ELEM VOLT'

	self.s.write( cmd + '\r\n' )

	cmd = ':OUTP ON'

	self.s.write( cmd + '\r\n' )

"""
def Volt_Source_Keithley_Ex(self):

	:SOUR:FUNC VOLT
	:SOUR:VOLT:MODE FIXED
	Set source range, level, compliance :SOUR:VOLT:RANG 20
	:SOUR:VOLT:LEV 10
	:SENS:CURR:PROT 10E-3
	Set measure function, range
	:SENS:FUNC "CURR"
	:SENS:CURR:RANG 10E-3
	:FORM:ELEM CURR
	Turn on output
	:OUTP ON
	Read data
	:READ?
	:OUTP OFF
	
	cmd = ':SOUR:FUNC VOLT'

	#self.s.write( cmd + '\r\n' )

	#cmd = ':SOUR:VOLT:MODE FIXED'

	#self.s.write( cmd + '\r\n' )

	cmd = ':SENS:CURR:PROT 0.1'

	self.s.write (cmd + '\r\n' )

	#cmd = ':SOUR:CURR:RANG MIN'

	#self.s.write( cmd + '\r\n' )

	cmd = ':SOUR:VOLT:LEV:IMM:AMPL 1'

	self.s.write( cmd + '\r\n' )

	#cmd = ':SENS:VOLT:PROT 2'

	#self.s.write( cmd + '\r\n' )

	#cmd = ':SENS:VOLT:RANGE 2'

	#self.s.write( cmd + '\r\n' )

	cmd = ':FORM:ELEM VOLT'

	self.s.write( cmd + '\r\n' )

	cmd = ':OUTP ON'

	self.s.write( cmd + '\r\n' )
"""

def Read_Keithley_Ex(self):

		
	cmd = ':READ?'

	self.s.write( cmd + '\r\n' )
	

	measurement = self.s.read(14)
	#print measurement 

	measurement = measurement.replace('E','e',1)
	"""
	measurement = measurement.replace("e+00","",1)
	measurement = measurement.replace("e-01","",1)
	measurement = measurement.replace("e-02","",1)
	measurement = measurement.replace("+", "",1) 
	print measurement
			#print type(measurement)
	"""
	measurement = float(measurement)
	"""	
	if measurement < 2.0:
				numb_of_zero = 1000.0
	else:	
				numb_of_zero = 100.0 
	"""
	measurement = measurement*1000      
	
	return measurement


def Volt_Source_Keithley_Ex(self,value,sens): #value in mV , sens in Volt
	
	"""
	:SOUR:FUNC VOLT
	:SOUR:VOLT:MODE FIXED
	Set source range, level, compliance :SOUR:VOLT:RANG 20
	:SOUR:VOLT:LEV 10
	:SENS:CURR:PROT 10E-3
	Set measure function, range
	:SENS:FUNC "CURR"
	:SENS:CURR:RANG 10E-3
	:FORM:ELEM CURR
	Turn on output
	:OUTP ON
	Read data
	:READ?
	:OUTP OFF
	
	"""
	value = float(value)
	value = value/1000
	value = str(value)
	
	value_command = [':SOUR:VOLT:LEV',value]
	value_command = string.join(value_command)
	#print value_command

	sens = float(sens)
	sens = str(sens)
	
	sens_command = [':SOUR:VOLT:RANG',sens]
	sens_command = string.join(sens_command)
	
	cmd = ':SENS:CURR:PROT 5E-4'

	self.s.write( cmd + '\r\n' )  

	cmd = ':SENS:VOLT:PROT 1.2'

	self.s.write (cmd + '\r\n' )

	cmd = ':SOUR:FUNC VOLT'

	self.s.write( cmd + '\r\n' )

	cmd = ':SOUR:VOLT:MODE FIXED'
  
	self.s.write( cmd + '\r\n' )  
	
	cmd = sens_command
	
	self.s.write( cmd + '\r\n' ) 
	
	#cmd = ':SOUR:VOLT:LEV 0.023'
	
	cmd = value_command

	self.s.write(cmd + '\r\n' )

	#cmd = ':SOUR:CURR:RANG MIN'

	#s.write( cmd + '\r\n' )

	#cmd = ':SENS:VOLT:PROT 2'

	#s.write( cmd + '\r\n' )

	#cmd = ':SENS:VOLT:RANGE 2'

	#s.write( cmd + '\r\n' )

	#cmd = ':FORM:ELEM VOLT'

	#s.write( cmd + '\r\n' )

	cmd = ':OUTP ON'

	self.s.write( cmd + '\r\n' )



